extends Control

signal command_requested(command: String)
var input_source: String = "NONE"
var last_reset: String = "START"
var reset_count: int = 0
var move_vector := Vector2.ZERO
var look_vector := Vector2.ZERO
var target_move: Vector2 = Vector2.ZERO
var target_look: Vector2 = Vector2.ZERO
var display_move: Vector2 = Vector2.ZERO
var display_look: Vector2 = Vector2.ZERO
var boost_held: bool = false
var jump_held: bool = false
var vertical_axis: float = 0.0
var fingers: Dictionary = {}
var offsets: Dictionary = {}
var buttons: Dictionary = {}
var left_center := Vector2.ZERO
var right_center := Vector2.ZERO
var radius: float = 70.0
var flight_mode: String = "WALK"
var interaction_label: String = ""
var ship_parked_near := false
var ship_lights := true
var ship_landing := false
var ship_landed := false
var button_radius := 23.0
const GREEN = Color("1BFD9C")

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	visible = false
	Input.emulate_mouse_from_touch = false
	get_viewport().size_changed.connect(on_viewport_resized)

func set_enabled(enabled: bool) -> void:
	last_reset = "ENABLED" if enabled else "DISABLED"
	reset_controls()
	visible = enabled
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if enabled else Input.MOUSE_MODE_CAPTURED
	queue_redraw()

func reset_controls() -> void:
	reset_count += 1
	fingers.clear()
	offsets.clear()
	move_vector = Vector2.ZERO
	look_vector = Vector2.ZERO
	target_move = Vector2.ZERO
	target_look = Vector2.ZERO
	display_move = Vector2.ZERO
	display_look = Vector2.ZERO
	boost_held = false
	jump_held = false
	vertical_axis = 0.0
	queue_redraw()

func on_viewport_resized() -> void:
	last_reset = "RESIZE"
	reset_controls()

func _exit_tree() -> void:
	# Never carry a held joystick into another scene.
	reset_controls()

func _notification(what: int) -> void:
	# A mouse-up outside the Godot window may never arrive as an input event.
	if what == NOTIFICATION_WM_MOUSE_EXIT and fingers.has(-100):
		pointer_end(-100)
	if what == NOTIFICATION_WM_WINDOW_FOCUS_OUT or what == NOTIFICATION_WM_WINDOW_FOCUS_IN:
		last_reset = "FOCUS OUT" if what == NOTIFICATION_WM_WINDOW_FOCUS_OUT else "FOCUS IN"
		reset_controls()
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func layout_controls() -> void:
	var screen: Vector2 = get_viewport_rect().size
	radius = clampf(minf(screen.x, screen.y) * 0.105, 36.0, 76.0)
	left_center = Vector2(radius + 12, screen.y - radius - 18)
	right_center = Vector2(screen.x - radius - 12, screen.y - radius - 18)
	var keys: Array = ["ship", "boost", "lights"] if flight_mode == "SHIP" else ["jetpack", "boost", "interact"]
	if flight_mode != "SHIP" and ship_parked_near: keys[0] = "ship"
	if flight_mode != "SHIP" and interaction_label.is_empty(): keys.pop_back()
	var span := maxf(30.0,right_center.x-left_center.x-radius*2.0-12.0)
	button_radius = clampf(span/float(keys.size()*2.5+1), 9.0, 30.0)
	var gap := button_radius*2.25
	buttons = {}
	for i in range(keys.size()):
		var key: String = keys[i]
		var tint := GREEN
		if key == "lights" and not ship_lights: tint = Color("79958f")
		if key == "ship" and ship_landing: tint = Color("FFBB55")
		buttons[key] = {"center": Vector2(screen.x*.5+(i-(keys.size()-1)*.5)*gap,screen.y-button_radius-22), "text":"", "color":tint}
	if flight_mode != "WALK":
		buttons["altitude"] = {"center": right_center+Vector2(0,-radius*2.55), "text":"", "color":GREEN}

func pointer_start(id: int, at: Vector2) -> void:
	if fingers.has(id):
		pointer_end(id)
	layout_controls()
	for key in buttons:
		var center: Vector2 = buttons[key]["center"]
		if key == "altitude":
			if absf(at.x - center.x) <= radius * 0.60 and absf(at.y - center.y) <= radius * 1.28:
				if fingers.values().has("altitude"):
					return
				fingers[id] = "altitude"
				pointer_drag(id, at)
				queue_redraw()
				return
			continue
		if at.distance_to(center) <= button_radius + 3.0:
			fingers[id] = str(key)
			refresh_buttons()
			if key in ["interact", "jetpack", "ship", "lights"]:
				command_requested.emit(str(key))
			queue_redraw()
			return
	var role: String = ""
	if at.distance_to(left_center) <= radius * 1.2:
		role = "move"
	elif at.distance_to(right_center) <= radius * 1.2:
		role = "look"
	if not role.is_empty() and not fingers.values().has(role):
		fingers[id] = role
		pointer_drag(id, at)

func pointer_drag(id: int, at: Vector2) -> void:
	if not fingers.has(id):
		return
	var role: String = fingers[id]
	if role == "altitude":
		if not buttons.has("altitude"):
			vertical_axis = 0.0
			return
		var center: Vector2 = buttons["altitude"]["center"]
		# The lever ignores X movement entirely. Up = ascend, down = descend.
		vertical_axis = -clampf((at.y - center.y) / (radius * 0.95), -1.0, 1.0)
		queue_redraw()
		return
	if role == "move" or role == "look":
		var center: Vector2 = left_center if role == "move" else right_center
		var displacement: Vector2 = ((at - center) / radius).limit_length(1.0)
		offsets[role] = displacement
		var strength: float = displacement.length()
		var value := Vector2.ZERO
		if strength > 0.08:
			value = displacement.normalized() * ((strength - 0.08) / 0.92)
		if role == "move":
			target_move = value
		else:
			target_look = value
	queue_redraw()

func pointer_end(id: int) -> void:
	if fingers.has(id):
		last_reset = "RELEASE " + str(id)
		var role: String = fingers[id]
		if role == "move":
			move_vector = Vector2.ZERO
			target_move = Vector2.ZERO
			display_move = Vector2.ZERO
		elif role == "look":
			look_vector = Vector2.ZERO
			target_look = Vector2.ZERO
			display_look = Vector2.ZERO
		elif role == "altitude":
			vertical_axis = 0.0
		offsets.erase(role)
		fingers.erase(id)
	refresh_buttons()
	queue_redraw()

func sample_controls(delta: float) -> void:
	# BUILD 009: recover lost pointer release. When a mouse pointer is dragged
	# out of the window or its release is consumed by a HUD, the held joystick
	# must return to center without needing the T-key reset.
	if fingers.has(-100) and not Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		pointer_end(-100)
	# Short, frame-rate-independent easing while held. Releases stop immediately.
	var weight: float = 1.0 - exp(-55.0 * delta)
	move_vector = move_vector.lerp(target_move, weight)
	look_vector = look_vector.lerp(target_look, weight)
	var raw_move: Vector2 = offsets.get("move", Vector2.ZERO)
	var raw_look: Vector2 = offsets.get("look", Vector2.ZERO)
	display_move = display_move.lerp(raw_move, weight)
	display_look = display_look.lerp(raw_look, weight)
	if target_move == Vector2.ZERO and move_vector.length_squared() < 0.000001:
		move_vector = Vector2.ZERO
	if target_look == Vector2.ZERO and look_vector.length_squared() < 0.000001:
		look_vector = Vector2.ZERO
	if visible:
		queue_redraw()

func refresh_buttons() -> void:
	var roles: Array = fingers.values()
	boost_held = roles.has("boost")
	jump_held = roles.has("jump")
	if not roles.has("altitude"):
		vertical_axis = 0.0

# World uses a small input reservation for its 3D logo. The existing pad owns
# active touch IDs and all pad hit regions, even when a logo is behind a control.
func _world_menu_pointer(event: InputEvent) -> bool:
	if not (event is InputEventScreenTouch or event is InputEventScreenDrag or event is InputEventMouseButton):
		return false
	var host := get_parent().get_parent()
	if not host.has_method("handle_world_menu_touch"):
		return false
	var id: int = -100 if event is InputEventMouseButton else event.index
	if fingers.has(id):
		return false
	if visible and event is InputEventMouseButton and Input.mouse_mode != Input.MOUSE_MODE_CAPTURED or visible and event is InputEventScreenTouch and event.pressed:
		layout_controls()
		var point: Vector2 = event.position
		if point.distance_to(left_center) <= radius * 1.2 or point.distance_to(right_center) <= radius * 1.2:
			return false
		for key in buttons:
			var center: Vector2 = buttons[key]["center"]
			if key == "altitude":
				if absf(point.x-center.x) <= radius*.60 and absf(point.y-center.y) <= radius*1.28:
					return false
			elif point.distance_to(center) <= button_radius+3.0:
				return false
	return host.call("handle_world_menu_touch", event)

func _input(event: InputEvent) -> void:
		var host := get_parent().get_parent()
		if host.has_method("world_menu_is_open") and host.call("world_menu_is_open"):
				return
		if _world_menu_pointer(event):
				get_viewport().set_input_as_handled()
				return
		# The dedicated globe view owns its own zoom/drag controls. Let GUI events pass.
		if host.has_method("globe_inspection_active") and host.call("globe_inspection_active"):
				return
		# Keyboard toggle works independently of pointer position.
		if event is InputEventKey:
				if event.pressed and not event.echo:
						if event.physical_keycode == KEY_T:
								set_enabled(not visible)
								get_viewport().set_input_as_handled()
				return

		# Touch IDs remain independent for simultaneous controls.
		if event is InputEventScreenTouch:
				input_source = "TOUCH"
				var id: int = event.index

				# Releases and cancellations MUST be handled first.
				# Never ignore a release because it enters the HUD.
				if not event.pressed or event.canceled:
						if fingers.has(id):
								pointer_end(id)
								get_viewport().set_input_as_handled()
						return

				if not visible:
						set_enabled(true)

				pointer_start(id, event.position)
				get_viewport().set_input_as_handled()
				return

		if event is InputEventScreenDrag:
				input_source = "TOUCH"
				if visible and fingers.has(event.index):
						pointer_drag(event.index, event.position)
						get_viewport().set_input_as_handled()
				return

		if event is InputEventMouseButton:
				input_source = "MOUSE"

				if event.button_index != MOUSE_BUTTON_LEFT:
						return

				# Never discard a mouse release, even over the HUD.
				if not event.pressed:
						if fingers.has(-100):
								pointer_end(-100)
								get_viewport().set_input_as_handled()
						return

				if not visible:
						return

				pointer_start(-100, event.position)
				get_viewport().set_input_as_handled()
				return

		if event is InputEventMouseMotion:
				input_source = "MOUSE"
				if visible and fingers.has(-100):
						pointer_drag(-100, event.position)
						get_viewport().set_input_as_handled()

func _draw() -> void:
	layout_controls()
	for role in ["move", "look"]:
		var center: Vector2 = left_center if role == "move" else right_center
		draw_circle(center, radius, Color(0.02, 0.04, 0.035, 0.24))
		draw_arc(center, radius, 0, TAU, 64, Color(0.11,.99,.61,.60), 2.0, true)
		var offset: Vector2 = display_move if role == "move" else display_look
		var thumb: Vector2 = center + offset * radius * 0.46
		draw_circle(thumb, radius * 0.62, Color(0.03, 0.08, 0.06, 0.42))
		draw_arc(thumb, radius * 0.62, 0, TAU, 48, GREEN, 2.0, true)
		draw_circle(thumb, 3, GREEN)
	for key in buttons:
		var center: Vector2 = buttons[key]["center"]
		var color: Color = buttons[key]["color"]
		var pressed: bool = fingers.values().has(key)
		if key == "altitude":
			# Airplane-style vertical track with a sliding handle.
			var half_width: float = radius * 0.31
			var half_height: float = radius * 0.94
			draw_rect(Rect2(center - Vector2(half_width, half_height), Vector2(half_width * 2.0, half_height * 2.0)), Color(0.025, 0.045, 0.055, 0.95))
			for end_y in [-half_height, half_height]:
				draw_circle(center + Vector2(0, end_y), half_width, Color(0.025, 0.045, 0.055, 0.95))
				draw_arc(center + Vector2(0, end_y), half_width, PI if end_y < 0.0 else 0.0, TAU if end_y < 0.0 else PI, 32, GREEN, 2.5, true)
			draw_line(center + Vector2(-half_width, -half_height), center + Vector2(-half_width, half_height), GREEN, 2.5)
			draw_line(center + Vector2(half_width, -half_height), center + Vector2(half_width, half_height), GREEN, 2.5)
			var handle := center + Vector2(0, -vertical_axis * half_height)
			draw_circle(handle, half_width * 1.24, GREEN if pressed else Color("E2FFDC"))
			draw_circle(handle, half_width * 0.62, Color("193E35"))
			continue
		var r: float = button_radius
		# 1AGE BUILD009 SOLID CONTEXT BUTTONS
		# Solid luminous buttons with high-contrast black glyphs.
		draw_circle(center, r, Color(color.r,color.g,color.b,.82 if pressed else .23))
		draw_arc(center, r, 0, TAU, 48, Color("E2FFDC"), 2.0, true)

		if key == "jetpack":
			# Minimal twin-thruster jetpack icon, black on vivid blue.
			var dark := Color("E2FFDC")
			var left_tank := Rect2(center + Vector2(-r * 0.58, -r * 0.38), Vector2(r * 0.32, r * 0.80))
			var right_tank := Rect2(center + Vector2(r * 0.26, -r * 0.38), Vector2(r * 0.32, r * 0.80))
			draw_rect(left_tank, dark, true)
			draw_rect(right_tank, dark, true)
			draw_rect(Rect2(center + Vector2(-r * 0.22, -r * 0.54), Vector2(r * 0.44, r * 0.84)), dark, true)
			draw_colored_polygon(PackedVector2Array([
				center + Vector2(-r * 0.56, r * 0.46),
				center + Vector2(-r * 0.26, r * 0.46),
				center + Vector2(-r * 0.41, r * 0.83)
			]), dark)
			draw_colored_polygon(PackedVector2Array([
				center + Vector2(r * 0.26, r * 0.46),
				center + Vector2(r * 0.56, r * 0.46),
				center + Vector2(r * 0.41, r * 0.83)
			]), dark)
			continue
		if key == "ship":
			var wing := PackedVector2Array([
				Vector2(0, -0.75), Vector2(0.18, -0.1), Vector2(0.72, 0.23),
				Vector2(0.72, 0.42), Vector2(0.15, 0.29), Vector2(0.12, 0.64),
				Vector2(0, 0.78), Vector2(-0.12, 0.64), Vector2(-0.15, 0.29),
				Vector2(-0.72, 0.42), Vector2(-0.72, 0.23), Vector2(-0.18, -0.1)
			])
			for j in range(wing.size()):
				wing[j] = center + wing[j] * r
			draw_colored_polygon(wing, Color("E2FFDC"))
			if ship_landed or (flight_mode == "SHIP" and not ship_landing):
				draw_line(center+Vector2(-r*.65,r*.85),center+Vector2(r*.65,r*.85),GREEN,2.0,true)
			continue
		var ink := Color("E2FFDC")
		if key == "lights":
			draw_arc(center+Vector2(-r*.15,0),r*.42,-PI/2,PI/2,20,ink,2.0,true)
			draw_line(center+Vector2(-r*.15,-r*.42),center+Vector2(-r*.15,r*.42),ink,2.0,true)
			for y in [-.35,0,.35]:
				draw_line(center+Vector2(r*.35,r*y),center+Vector2(r*.75,r*y),ink,2.0,true)
		elif key == "boost":
			draw_polyline(PackedVector2Array([center+Vector2(-r*.55,r*.25),center+Vector2(0,-r*.40),center+Vector2(r*.55,r*.25)]),ink,2.5,true)
			draw_polyline(PackedVector2Array([center+Vector2(-r*.55,r*.65),center,center+Vector2(r*.55,r*.65)]),ink,2.5,true)
		else:
			draw_circle(center,r*.40,ink,false,2.0,true)
			draw_circle(center,r*.13,ink)



# BUILD 008.2 — INPUT RECOVERY
func recover_released_inputs() -> void:
	# Recover if a mouse release was missed.
	if fingers.has(-100):
		if not Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
			pointer_end(-100)

	var active_roles: Array = fingers.values()

	if not active_roles.has("move"):
		move_vector = Vector2.ZERO
		target_move = Vector2.ZERO
		display_move = Vector2.ZERO

	if not active_roles.has("look"):
		look_vector = Vector2.ZERO
		target_look = Vector2.ZERO
		display_look = Vector2.ZERO

	if not active_roles.has("altitude"):
		vertical_axis = 0.0

	if not active_roles.has("boost"):
		boost_held = false

	if not active_roles.has("jump"):
		jump_held = false
