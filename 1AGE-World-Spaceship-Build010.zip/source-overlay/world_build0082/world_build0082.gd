extends "res://room.gd"
# 1AGE WORLD | Build 004 walkable-glass and contextual actions (non-destructive).
# Based on the World movement and shared touch/room UI system.
# Original Room 001, orbital scene and game scenes remain untouched.

const DECK_Y := 45.0
const SHIP_ARRIVAL := Vector3(0, 81, 112)
const SHIP_PITCH := -0.30
const ORBIT_R := 42.0
const PIECES := 64
const PAVILION_R := 60.0
const DARK := Color("050708")
const DIM := Color("15231F")
const FROST := Color(0.35, 0.85, 0.77, 0.17)
const APPS := ["Page", "Space", "Games", "Quest", "Work", "Forum", "Shop", "Exchange", "Cash", "Design"]
const APP_COLORS := ["55B8FF", "E2FFDC", "FFBB55", "C18BFF", "55B8FF", "E2FFDC", "FFBB55", "50E3D4", "1BFD9C", "C18BFF"]
const DESTINATIONS := ["https://1age.page/", "https://1age.space/", "res://games_complex/games_complex.tscn", "https://1age.quest/", "https://1age.work/", "https://1age.forum/", "https://1age.shop/", "https://1age.exchange/application.html", "https://1age.cash/", "https://1age.design/"]
const REGIONS := ["EARTH", "AFRICA", "ASIA", "EUROPE", "NORTH AMERICA", "SOUTH AMERICA", "OCEANIA"]

var earth: MeshInstance3D
var starfield: MultiMeshInstance3D
var floor_tiles: Array[MeshInstance3D] = []
var floor_positions: Array[Vector3] = []
var luminous_material: StandardMaterial3D
var unlit_material: StandardMaterial3D
var old_lit: Dictionary = {}
var effect_time := 0.0
var effect_index := 0
var orb_nodes: Array[Node3D] = []
var orb_lights: Array[MeshInstance3D] = []
var app_centers: Array[Vector3] = []
var console_active := false
var selected_region := 0
var screen: Label
var destination_idx := -1
var dock_idx := -1
var action_button: Button
var guidance_label: Label3D
var guidance_last := -1
var clock_002 := 0.0
var subtle_step_material: StandardMaterial3D
var build008_ui: CanvasLayer
var build008_hint: Label
var design_platform: Node3D
var world_menu: Node3D
var platform_terminals: Node3D
var adaptive: Node3D
var ship_vehicle: Node3D

func _ready() -> void:
    movement = preload(
        "res://world_build0082/movement_controller.gd"
    ).new()
    preload("res://input_actions.gd").register_defaults()
    touch_controls = preload("res://world_build0082/touch_controls.gd").new()
    _environment()
    subtle_step_material = _mat(Color("157B50"), true)
    luminous_material = _mat(GREEN, true)
    unlit_material = _transparent_floor()
    _stars()
    _earth()
    _ring_walkway()
    _application_platforms()
    _control_console()
    _player_and_ui()
    _build_008_interface()
    ship_vehicle = preload("res://world_build0082/ship_vehicle.gd").new()
    ship_vehicle.install(self)
    design_platform = preload("res://world_build0082/design_platform.gd").new()
    design_platform.install(self)
    world_menu = preload("res://world_build0082/world_hologram_menu.gd").new()
    world_menu.install(self, build008_ui)
    platform_terminals = preload("res://world_build0082/platforms/platform_terminals.gd").new()
    platform_terminals.install(self)
    add_child(preload("res://world_build0082/world_details.gd").new())
    adaptive = preload("res://world_build0082/adaptive_space.gd").new()
    adaptive.install(self, build008_ui)
    if not _restore_platform_arrival():
        _apply_platform_entry()
    # Temporarily disabled for performance testing


# 1AGE World — Unified Platform Entry
# One 3D World, with individual platform domain entrances.
# Only browser entry behavior is affected.
func _apply_platform_entry() -> void:
    if not OS.has_feature("web"):
        return

    var browser_code := """
        (() => {
            const host = window.location.hostname.toLowerCase();
            const params = new URLSearchParams(window.location.search);
            const testEntry = params.get('entry') || params.get('platform');

            if (testEntry) {
                return testEntry.toLowerCase();
            }

            if (host.startsWith('1age.')) {
                return host.split('.').pop();
            }

            if (host.startsWith('www.1age.')) {
                return host.split('.').pop();
            }

            return 'world';
        })()
    """

    var requested := str(
        JavaScriptBridge.eval(browser_code)
    ).to_lower()

    _activate_requested_entry(requested)

func _activate_requested_entry(requested: String) -> void:
    if requested == "world" or requested.is_empty():
        return

    if requested.capitalize() in APPS:
        adaptive.activate(requested)
        return

    if requested.capitalize() in ["Store", "Blog", "Plus"]:
        platform_terminals.open(requested.capitalize())
        return


func reset_ship_arrival() -> void:
    touch_controls.reset_controls()
    player.position = SHIP_ARRIVAL
    player.rotation.y = 0.0
    camera.rotation.x = SHIP_PITCH
    movement.mode = movement.Mode.SHIP
    touch_controls.flight_mode = movement.mode_name()
    player.velocity = Vector3.ZERO
    if is_instance_valid(ship_vehicle): ship_vehicle.reset()

func _place_at_platform(index: int) -> void:
    movement.mode = movement.Mode.WALK
    touch_controls.flight_mode = movement.mode_name()
    # Start near the inner edge of the selected platform.
    # Face its logo and application name, not Earth.
    var center: Vector3 = app_centers[index]
    var outward: Vector3 = Vector3(center.x, 0.0, center.z).normalized()

    player.position = (
        center - outward * 12.0 + Vector3.UP * 0.35
    )

    player.look_at(
        Vector3(center.x, player.position.y, center.z),
        Vector3.UP
    )

    if is_instance_valid(ship_vehicle):
        ship_vehicle.park_at(center - outward * 8.5 + Vector3.UP * .35, player.rotation.y)
        ship_vehicle.sync()
    # Aim the view upward toward the existing branding.
    camera.look_at(center + Vector3.UP * 8.0, Vector3.UP)

    player.velocity = Vector3.ZERO


# Keep this transient position in the running SceneTree across a native scene transition.
func _restore_platform_arrival() -> bool:
    if not get_tree().has_meta("world_platform_return"):
        return false
    var saved: Dictionary = get_tree().get_meta("world_platform_return")
    get_tree().remove_meta("world_platform_return")
    player.position = saved.position
    player.rotation.y = saved.heading
    camera.rotation.x = saved.pitch
    movement.mode = saved.mode
    if saved.has("adaptive_mode"): adaptive.activate(saved.adaptive_mode)
    player.velocity = Vector3.ZERO
    return true

func _enter_native_platform(destination: String) -> void:
    var tree := get_tree()
    tree.set_meta("world_platform_return", {
        "position": player.position, "heading": player.rotation.y,
        "pitch": camera.rotation.x, "mode": movement.mode, "adaptive_mode": adaptive.mode,
    })
    touch_controls.reset_controls()
    if tree.change_scene_to_file(destination) != OK:
        tree.remove_meta("world_platform_return")
        push_warning("Could not open native destination: " + destination)

func _mat(color: Color, bright: bool = false) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = 0.28 if bright else 0.78
    if bright:
        m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        m.emission_enabled = true
        m.emission = color
        m.emission_energy_multiplier = 1.7
    return m

func _transparent_floor() -> StandardMaterial3D:
    var mat := StandardMaterial3D.new()
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.albedo_color = Color(0.07, 0.20, 0.17, 0.46)
    mat.metallic = 0.25
    mat.roughness = 0.12
    mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    return mat

func _environment() -> void:
    var world := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color("000105")
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color("B6C5D1")
    env.ambient_light_energy = 0.75
    world.environment = env
    add_child(world)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-44, 24, 0)
    sun.light_energy = 0.9
    add_child(sun)

func _stars() -> void:
    # MultiMesh is significantly cheaper than hundreds of individually rendered spheres.
    var rng := RandomNumberGenerator.new()
    rng.seed = 13072026
    var multi := MultiMesh.new()
    multi.transform_format = MultiMesh.TRANSFORM_3D
    var mesh := SphereMesh.new()
    mesh.radius = 0.16
    mesh.height = 0.32
    mesh.radial_segments = 4
    mesh.rings = 2
    multi.mesh = mesh
    multi.instance_count = 1400
    for i in range(multi.instance_count):
        var dir := Vector3(rng.randf_range(-1, 1), rng.randf_range(-1, 1), rng.randf_range(-1, 1)).normalized()
        if dir.length() < 0.1:
            dir = Vector3.UP
        var dist := rng.randf_range(95.0, 360.0)
        var at := Vector3(0, DECK_Y, 0) + dir * dist
        var scale := rng.randf_range(0.4, 1.55)
        multi.set_instance_transform(i, Transform3D(Basis().scaled(Vector3.ONE * scale), at))
    starfield = MultiMeshInstance3D.new()
    starfield.multimesh = multi
    starfield.material_override = _mat(Color("B8D8F4"), true)
    add_child(starfield)

func _earth() -> void:
    earth = sphere(self, Vector3(0, DECK_Y + 1.0, 0), 21.0, Color.WHITE)
    var earth_mat := material(Color.WHITE)
    earth_mat.albedo_texture = load("res://design/assets/world-surface.png")
    earth.material_override = earth_mat
    sphere(self, Vector3(-53, DECK_Y + 28, -95), 10.0, Color("C9CCD0"))
    var violet := ring(self, Vector3(0, DECK_Y + 1, 0), 21.7, Color("B18AFF"))
    violet.rotation_degrees.x = 90.0

func _glass(at: Vector3, size: Vector3, yaw: float) -> void:
    var mesh := BoxMesh.new()
    mesh.size = size
    var node := MeshInstance3D.new()
    node.mesh = mesh
    var m := StandardMaterial3D.new()
    m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    m.albedo_color = FROST
    m.roughness = 0.12
    m.depth_draw_mode = BaseMaterial3D.DEPTH_DRAW_DISABLED
    m.cull_mode = BaseMaterial3D.CULL_DISABLED
    node.material_override = m
    node.position = at
    node.rotation.y = yaw
    add_child(node)

func _rail_segment(radius: float, angle: float, segment_length: float, inner: bool) -> void:
    var d := Vector3(sin(angle), 0, cos(angle))
    var p := d * radius + Vector3.UP * DECK_Y
    if inner:
        var wall := box(p + Vector3.UP * 1.18, Vector3(segment_length + 0.24, 2.35, 0.21), Color("010102"), false)
        wall.rotation.y = angle
        var trim := box(p + Vector3.UP * 2.41, Vector3(segment_length + 0.24, 0.085, 0.25), Color("9945FF"), false, true)
        trim.rotation.y = angle
        var body := StaticBody3D.new()
        body.position = p + Vector3.UP * 1.2
        body.rotation.y = angle
        var col := CollisionShape3D.new()
        var bounds := BoxShape3D.new()
        bounds.size = Vector3(segment_length + 0.24, 2.4, 0.28)
        col.shape = bounds
        body.add_child(col)
        add_child(body)
        # Single orbiting title replaces repeated wall lettering.
    else:
        var beam := box(p + Vector3.UP * 1.0, Vector3(segment_length, 0.1, 0.16), GREEN, false, true)
        beam.rotation.y = angle
        var body := StaticBody3D.new()
        body.position = p + Vector3.UP * 0.52
        body.rotation.y = angle
        var col := CollisionShape3D.new()
        var shape := BoxShape3D.new()
        shape.size = Vector3(segment_length, 1.05, 0.15)
        col.shape = shape
        body.add_child(col)
        add_child(body)

func _tile(at: Vector3, size: Vector3, angle: float = 0.0) -> void:
    var tile := box(at, size, DARK, false)
    tile.rotation.y = angle
    tile.material_override = unlit_material
    floor_tiles.append(tile)
    floor_positions.append(at)

func _ring_walkway() -> void:
    # Continuous INVISIBLE collision deck. Glass is visual only; transparency never changes physics.
    # Each slab overlaps its neighbors along the circumference to avoid falling through seams.
    var segment: float = TAU * ORBIT_R / float(PIECES)
    for i in range(PIECES):
        var a: float = TAU * (float(i) + 0.5) / float(PIECES)
        var direction: Vector3 = Vector3(sin(a), 0, cos(a))
        var at: Vector3 = direction * ORBIT_R + Vector3.UP * DECK_Y
        var collision_body := StaticBody3D.new()
        collision_body.name = "GlassFloorCollision_%d" % i
        collision_body.position = at - Vector3.UP * 0.17
        collision_body.rotation.y = a
        var collision_shape := CollisionShape3D.new()
        var deck_shape := BoxShape3D.new()
        deck_shape.size = Vector3(segment + 1.2, 0.40, 11.2)
        collision_shape.shape = deck_shape
        collision_body.add_child(collision_shape)
        add_child(collision_body)
        # Translucent glass panels, with independent luminous step lighting.
        for radial in [38.8, 42.0, 45.2]:
            var center: Vector3 = direction * radial + Vector3.UP * DECK_Y
            _glass(center + Vector3.UP * 0.047, Vector3(segment + 0.5, 0.035, 3.55), a)
        _rail_segment(36.75, a, TAU * 36.75 / float(PIECES) + 0.2, true)
        # Outer ring remains open for walking toward applications.
    for rad in [36.75, 47.25]:
        ring(self, Vector3(0, DECK_Y + 0.08, 0), rad, GREEN)
    guidance_label = Label3D.new()
    guidance_label.font_size = 37
    guidance_label.pixel_size = 0.006
    guidance_label.modulate = GREEN
    guidance_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    guidance_label.position = Vector3(0, DECK_Y + 2.1, 47.8)
    guidance_label.text = "1AGE WORLD  /  WALK TO EXPLORE"
    add_child(guidance_label)
    guidance_label.visible = false


func _application_platforms() -> void:
    for i in range(APPS.size()):
        var accent: Color = Color(APP_COLORS[i])
        var a: float = PI - TAU * float(i) / float(APPS.size())
        var direction := Vector3(sin(a), 0, cos(a))
        var tangent := Vector3(cos(a), 0, -sin(a))
        var at: Vector3 = direction * PAVILION_R + Vector3.UP * DECK_Y
        app_centers.append(at)

        var disk := MeshInstance3D.new()
        var shape := CylinderMesh.new()
        shape.top_radius = 15.0
        shape.bottom_radius = 15.0
        shape.height = 0.45
        shape.radial_segments = 64
        disk.name = "Platform_" + APPS[i]
        disk.mesh = shape
        disk.material_override = _mat(DARK)
        disk.position = at - Vector3.UP * 0.20
        add_child(disk)

        var solid := StaticBody3D.new()
        solid.position = disk.position
        var collision := CollisionShape3D.new()
        var cylinder := CylinderShape3D.new()
        cylinder.radius = 15.0
        cylinder.height = 0.45
        collision.shape = cylinder
        solid.add_child(collision)
        add_child(solid)

        ring(self, at + Vector3.UP * 0.06, 14.7, GREEN)

        for gx in range(-6, 7):
            for gz in range(-6, 7):
                var ox: float = float(gx) * 2.12
                var oz: float = float(gz) * 2.12
                if Vector2(ox, oz).length() > 12.3:
                    continue
                var pos: Vector3 = at + tangent * ox + direction * oz
                _tile(pos + Vector3.UP * 0.055, Vector3(2.0, 0.025, 2.0), a)


        var orb := Node3D.new()
        orb.position = at + Vector3.UP * 3.8
        add_child(orb)
        var shell := sphere(orb, Vector3.ZERO, 1.05, accent, true)
        var orb_mat := _mat(Color(accent.r, accent.g, accent.b, 0.46), true)
        orb_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        shell.material_override = orb_mat

        for tilt in [0.0, PI / 2.0, PI / 3.0]:
            var hoop := ring(orb, Vector3.ZERO, 1.5, accent)
            hoop.rotation.x = tilt

        orb_nodes.append(orb)
        orb_lights.append(shell)
        orb.visible = false

func _control_console() -> void:
    # The interactive console is the black inner balcony wall (see _rail_segment).
    pass

func _player_and_ui() -> void:
    movement.world_min = Vector3(-250, DECK_Y - 85, -250)
    movement.world_max = Vector3(250, DECK_Y + 190, 250)
    player = CharacterBody3D.new()
    player.position = SHIP_ARRIVAL
    movement.mode = movement.Mode.SHIP
    var collision := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.3
    capsule.height = 1.8
    collision.shape = capsule
    collision.position.y = 0.9
    player.add_child(collision)
    camera = Camera3D.new()
    camera.position.y = 1.80
    camera.fov = 78.0
    camera.rotation.x = SHIP_PITCH
    player.add_child(camera)
    add_child(player)
    camera.current = true
    var overlay := CanvasLayer.new()
    add_child(overlay)
    overlay.add_child(touch_controls)
    room_ui.touch_controls = touch_controls
    overlay.add_child(room_ui)
    room_ui.visible = false
    touch_controls.command_requested.connect(_touch_command)
    touch_controls.flight_mode = movement.mode_name()
    screen = Label.new()
    screen.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
    screen.position = Vector2(20, -155)
    screen.add_theme_color_override("font_color", GREEN)
    screen.add_theme_font_size_override("font_size", 17)
    overlay.add_child(screen)
    action_button = Button.new()
    action_button.text = ""
    action_button.custom_minimum_size = Vector2(154, 54)
    action_button.add_theme_color_override("font_color", GREEN)
    action_button.add_theme_font_size_override("font_size", 18)
    overlay.add_child(action_button)
    action_button.pressed.connect(_on_action_pressed)
    action_button.visible = false
    get_viewport().size_changed.connect(_position_action_button)
    _position_action_button()
    call_deferred("initialize_input_mode")

func _position_action_button() -> void:
    if not is_instance_valid(action_button):
        return
    var view: Vector2 = get_viewport().get_visible_rect().size
    action_button.position = Vector2(maxf(8.0, view.x - 332.0), maxf(130.0, view.y - 328.0))

func _on_action_pressed() -> void:
    _interact()

func initialize_input_mode() -> void:
    touch_controls.set_enabled(true)

func _destination(index: int) -> void:
    if index < 0 or index >= DESTINATIONS.size():
        return
    if adaptive.mode != "world":
        adaptive.open_role(index)
        return
    adaptive.activate(APPS[index].to_lower())

func globe_inspection_active() -> bool:
    return is_instance_valid(adaptive) and adaptive.inspection

func handle_world_menu_touch(event: InputEvent) -> bool:
    if world_menu_is_open():
        return false
    if is_instance_valid(world_menu) and world_menu.consume_pointer(event):
        return true
    if is_instance_valid(adaptive) and adaptive.consume_pointer(event):
        return true
    return _consume_platform_pointer(event)

var platform_touches: Dictionary = {}

func _platform_hit(point: Vector2) -> bool:
    if dock_idx < 0 or not orb_nodes[dock_idx].visible:
        return false
    var at: Vector3 = orb_nodes[dock_idx].global_position
    return not camera.is_position_behind(at) and camera.unproject_position(at).distance_to(point) < 42.0

func _consume_platform_pointer(event: InputEvent) -> bool:
    if event is InputEventScreenDrag and platform_touches.has(event.index):
        if event.position.distance_to(platform_touches[event.index]) > 12.0:
            platform_touches.erase(event.index)
        return true
    if event is InputEventScreenTouch:
        if event.pressed and not event.canceled and _platform_hit(event.position):
            platform_touches[event.index] = event.position
            return true
        if not event.pressed and platform_touches.has(event.index):
            platform_touches.erase(event.index)
            if not event.canceled and _platform_hit(event.position):
                _interact()
            return true
    if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
        var point: Vector2 = event.position if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED else get_viewport().get_visible_rect().get_center()
        if _platform_hit(point):
            _interact()
            return true
    return false

func world_menu_is_open() -> bool:
    return (is_instance_valid(world_menu) and world_menu.is_open()) or terminal_active() or (is_instance_valid(adaptive) and adaptive.is_open())

func terminal_active() -> bool:
    return is_instance_valid(platform_terminals) and not platform_terminals.opened.is_empty()

func handle_world_menu_controller(buttons: Array[bool], prior: Array[bool]) -> bool:
    if is_instance_valid(adaptive) and adaptive.is_open():
        return adaptive.consume_controller(buttons,prior)
    if terminal_active():
        return platform_terminals.consume_controller(buttons, prior)
    if is_instance_valid(world_menu) and world_menu.consume_controller(buttons, prior): return true
    if is_instance_valid(ship_vehicle) and buttons[JOY_BUTTON_DPAD_UP] and not prior[JOY_BUTTON_DPAD_UP]:
        ship_vehicle.toggle_lights()
        return true
    if globe_inspection_active(): return adaptive.consume_controller(buttons,prior)
    return false

func _interact() -> void:
    if world_menu_is_open():
        return
    if ship_vehicle.aboard():
        ship_vehicle.board_or_land()
        return
    if ship_vehicle.can_board() and dock_idx < 0:
        ship_vehicle.board_or_land()
        return
    if adaptive.mode != "world" and dock_idx < 0:
        adaptive.start_inspection()
        return
    if console_active:
        selected_region = (selected_region + 1) % REGIONS.size()
    elif dock_idx >= 0:
        _destination(dock_idx)
    elif player.position.distance_to(Vector3(0, DECK_Y, 37.55)) < 5.6:
        console_active = true

func _touch_command(command: String) -> void:
    if command == "jetpack":
        if ship_vehicle.aboard():
            ship_vehicle.board_or_land()
            return
        movement.activate_flight(player, 1)
        touch_controls.flight_mode = movement.mode_name()
        return
    if command == "ship":
        ship_vehicle.board_or_land()
        touch_controls.flight_mode = movement.mode_name()
        return
    match command:
        "interact": _interact()
        "fly":
            if ship_vehicle.aboard() or ship_vehicle.can_board(): ship_vehicle.board_or_land()
            else: movement.toggle_mode(player)
        "lights": ship_vehicle.toggle_lights()
        "home":
            touch_controls.reset_controls()
            get_tree().change_scene_to_file("res://main.tscn")

func _unhandled_input(event: InputEvent) -> void:
    if world_menu_is_open():
        return
    if is_instance_valid(adaptive) and adaptive.inspection:
        if adaptive.consume_pointer(event):
            get_viewport().set_input_as_handled()
        elif event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
            adaptive.stop_inspection()
        return
    if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        player.rotate_y(-event.relative.x * 0.0022)
        camera.rotation.x = clampf(camera.rotation.x - event.relative.y * 0.0022, -1.35, 1.35)
    if event is InputEventMouseButton and event.pressed:
        Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
    if event is InputEventKey and event.pressed and not event.echo:
        if event.keycode == KEY_ESCAPE:
            if is_instance_valid(design_platform) and design_platform.expanded:
                design_platform.close_design()
                return
            if console_active:
                console_active = false
            else:
                Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED else Input.MOUSE_MODE_CAPTURED
        elif event.is_action_pressed("toggle_fly"):
            _touch_command("fly")
        elif event.keycode == KEY_B:
            _touch_command("ship")
        elif event.keycode == KEY_L:
            _touch_command("lights")
        elif event.keycode == KEY_F11:
            var full := DisplayServer.window_get_mode() == DisplayServer.WINDOW_MODE_FULLSCREEN
            DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED if full else DisplayServer.WINDOW_MODE_FULLSCREEN)
        elif event.is_action_pressed("interact") or event.keycode == KEY_ENTER:
            _interact()
        elif console_active:
            if event.keycode == KEY_LEFT:
                selected_region = posmod(selected_region - 1, REGIONS.size())
            elif event.keycode == KEY_RIGHT:
                selected_region = (selected_region + 1) % REGIONS.size()
            elif event.keycode == KEY_1:
                get_tree().change_scene_to_file("res://main.tscn")
            elif event.keycode == KEY_2:
                get_tree().change_scene_to_file("res://sol_road.tscn")
            elif event.keycode == KEY_3:
                OS.shell_open("https://1age.com")
            elif event.keycode == KEY_4:
                _destination(2)

func _physics_process(delta: float) -> void:
    _update_world_orbit_title(delta)
    touch_controls.sample_controls(delta)
    touch_controls.recover_released_inputs()
    touch_controls.flight_mode = movement.mode_name()
    clock_002 += delta
    var active: bool = not world_menu_is_open() and not room_ui.manual_open and DisplayServer.window_is_focused() and (Input.mouse_mode == Input.MOUSE_MODE_CAPTURED or touch_controls.visible)
    if is_instance_valid(adaptive) and adaptive.inspection: active = false
    if active and touch_controls.visible:
        player.rotate_y(-touch_controls.look_vector.x * 1.8 * delta)
        camera.rotation.x = clampf(camera.rotation.x - touch_controls.look_vector.y * 1.8 * delta, -1.35, 1.35)
    if not ship_vehicle.tick(delta, active):
        movement.update(player, camera, delta, active and not console_active, touch_controls.move_vector, touch_controls.boost_held, touch_controls.jump_held, touch_controls.vertical_axis)
    if player.position.y < DECK_Y - 18:
        reset_ship_arrival()
    if not is_instance_valid(adaptive) or adaptive.mode == "world" or not adaptive.inspection:
        earth.rotation.y += delta * TAU / 150.0
    dock_idx = -1
    var nearest := 5.6
    for i in range(app_centers.size()):
        var p: Vector3 = app_centers[i]
        var dist := Vector2(player.position.x - p.x, player.position.z - p.z).length()
        orb_nodes[i].visible = dist < 15.0
        orb_nodes[i].rotation.y = clock_002 * 0.4
        orb_nodes[i].position.y = DECK_Y + 3.8 + sin(clock_002 * 1.5 + float(i)) * 0.2
        if dist < nearest and absf(player.position.y - DECK_Y) < 5.0:
            nearest = dist
            dock_idx = i
    effect_time += delta
    if effect_time >= 0.10:
        effect_time = 0.0
        _update_steps()
    var near_console: bool = player.position.distance_to(Vector3(0, DECK_Y, 37.55)) < 5.6
    if is_instance_valid(action_button):
        action_button.hide()
    touch_controls.interaction_label = "available" if not ship_vehicle.aboard() and (dock_idx >= 0 or near_console or console_active) else ""
    if is_instance_valid(guidance_label): guidance_label.hide()
    room_ui.mode_text = movement.mode_name()
    _refresh_008_hint()
    if console_active:
        room_ui.station_text = "GLOBE CONTROL  ·  ARROWS CHANGE REGION  ·  E NEXT  ·  ESC CLOSE"
        screen.text = "1AGE COMMAND DECK\nLOCATION PREVIEW: %s\n1  ROOM 001     2  PORTLAND\n3  1AGE.COM     4  GAMES\nCOUNTRY / CITY NAVIGATION: FUTURE BUILD\nPEOPLE LOCATION SEARCH: NOT ENABLED" % REGIONS[selected_region]
    else:
        screen.text = ""
        if dock_idx >= 0:
            room_ui.station_text = "[E] ENTER " + adaptive.role(dock_idx)
        elif player.position.distance_to(Vector3(0, DECK_Y, 37.55)) < 5.6:
            room_ui.station_text = "[E] OPEN EARTH CONTROL CENTER"
        else:
            room_ui.station_text = "COSMIC PROMENADE  /  WALK · EXPLORE · FLY"

func _update_steps() -> void:
    var winner := -1
    var nearest := 999.0
    if absf(player.position.y - DECK_Y) < 2.3 and movement.mode_name() == "WALK":
        for i in range(floor_positions.size()):
            var p: Vector3 = floor_positions[i]
            var dist: float = Vector2(p.x - player.position.x, p.z - player.position.z).length_squared()
            if dist < nearest and dist < 3.0:
                nearest = dist
                winner = i
    for id in old_lit:
        if int(id) != winner:
            floor_tiles[int(id)].material_override = unlit_material
    old_lit.clear()
    if winner >= 0:
        floor_tiles[winner].material_override = subtle_step_material
        old_lit[winner] = true


func _build_008_interface() -> void:
    build008_ui = CanvasLayer.new()
    build008_ui.layer = 12
    add_child(build008_ui)
    build008_hint = Label.new()
    build008_hint.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
    build008_hint.offset_left = 170
    build008_hint.offset_right = -180
    build008_hint.offset_top = -140
    build008_hint.offset_bottom = -104
    build008_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    build008_hint.add_theme_color_override("font_color", Color("E2FFDC"))
    build008_hint.add_theme_font_size_override("font_size", 21)
    build008_ui.add_child(build008_hint)
    _refresh_008_hint()

func _refresh_008_hint() -> void:
    if not is_instance_valid(build008_hint):
        return
    build008_hint.hide()


# BUILD 008.2 — EXTRUDED 3D BALCONY BRANDING
# One moving 3D title, retaining the approved orbit.

var world_orbit_title: MeshInstance3D
var world_title_angle: float = 0.0

func _update_world_orbit_title(delta: float) -> void:
    if not is_instance_valid(world_orbit_title):
        var bold_font: Font = load(
            "res://world_build0082/world-bold.ttf"
        )

        var letters := TextMesh.new()
        letters.font = bold_font
        letters.text = adaptive.mode_title() if is_instance_valid(adaptive) else "1AGE World"
        letters.font_size = 48
        letters.pixel_size = 0.047
        letters.depth = 0.32

        world_orbit_title = MeshInstance3D.new()
        world_orbit_title.name = "WorldControlWall3DTitle"
        world_orbit_title.mesh = letters

        var mat := StandardMaterial3D.new()
        mat.albedo_color = Color.WHITE
        mat.roughness = 0.38
        mat.metallic = 0.12
        mat.cull_mode = BaseMaterial3D.CULL_DISABLED
        mat.emission_enabled = true
        mat.emission = Color.WHITE
        mat.emission_energy_multiplier = 0.3

        world_orbit_title.material_override = mat
        add_child(world_orbit_title)

    # Preserve the existing slow circular orbit.
    world_title_angle = wrapf(
        world_title_angle + delta * 0.12,
        0.0,
        TAU
    )

    world_orbit_title.position = Vector3(
        sin(world_title_angle) * 38.4,
        DECK_Y + 1.18,
        cos(world_title_angle) * 38.4
    )

    world_orbit_title.rotation.y = world_title_angle
