extends RefCounted
# Presentation-only opportunity taxonomy. No balance, payments, lending, or ledger writes.
const ITEMS := [
    {"app":"Page","earn":"Approved profile and community contributions","use":"Eligible profile and community features","tags":"identity community social","scope":"global"},
    {"app":"Space","earn":"Property research and authorized virtual space development","use":"Eligible virtual space services","tags":"property building storefront real estate spaces","scope":"pilot"},
    {"app":"Games","earn":"Funded achievement and game contribution rewards","use":"Eligible game content","tags":"game gaming achievements boxing","scope":"global"},
    {"app":"Quest","earn":"Funded city-building, photo, video and verification missions","use":"Eligible mission-related features","tags":"quests photos photography video city building verification missions","scope":"pilot"},
    {"app":"Work","earn":"Approved contributor opportunities with an allocated credit budget","use":"Eligible contributor tools","tags":"work jobs contribution employer","scope":"pilot"},
    {"app":"Forum","earn":"Approved community support and moderation contributions","use":"Eligible community features","tags":"forum community moderation discussions","scope":"global"},
    {"app":"Shop","earn":"Eligible virtual merchandise sales","use":"Eligible virtual purchases","tags":"shop shopping seller merchant products","scope":"global"},
    {"app":"Exchange","earn":"No earning service enabled","use":"Learn the difference between Cash and external cryptocurrency","tags":"exchange wallet payment crypto services","scope":"global"},
    {"app":"Cash","earn":"Review earning opportunities","use":"Account access and transaction history through the existing secure Cash portal","tags":"account balance credits activity history","scope":"global"},
    {"app":"Design","earn":"Approved building, interior and asset creation","use":"Eligible creative tools and assets","tags":"design creator architecture building model assets","scope":"pilot"}
]
const DISCLAIMER := "Planned uses only · No funded offers, amounts, transfers or redemption are enabled in this build."
static func search(query: String) -> Array:
    var q := query.to_lower()
    for c in [".",",","-","/"]: q=q.replace(c," ")
    var terms := q.split(" ",false)
    var pilot := false
    for term in terms:
        if term in ["portland","hq1","oregon","washington","dc","d","c","hq2","anacostia"]: pilot=true
    var result: Array=[]
    for item in ITEMS:
        if pilot and item.scope!="pilot": continue
        var hay: String=(item.app+" "+item.earn+" "+item.use+" "+item.tags).to_lower()
        var ok:=true
        for term in terms:
            if term in ["in","near","for","the","a","earn","use","cash","1age","opportunities","opportunity","portland","hq1","oregon","washington","dc","d","c","hq2","anacostia"]: continue
            if term not in hay: ok=false; break
        if ok: result.append(item)
    return result
