extends Node3D

const ACTIVE := Color("1BFD9C")
const DORMANT := Color("E2FFDC")
const SIZE := Vector2i(680,480)
const CATALOG := preload("res://world_build0082/platforms/platform_catalog.gd")
const SHOP := preload("res://world_build0082/platforms/shop_drafts.gd")
const QUEST := preload("res://world_build0082/platforms/quest_progress.gd")
const CONTENT := {
    "Page":"res://world_build0082/platforms/page_founder.json",
    "Blog":"res://world_build0082/platforms/blog_publications.json",
}

var world: Node3D
var board: MeshInstance3D
var screen: SubViewport
var layout: VBoxContainer
var heading: Label
var body: Label
var body_scroll: ScrollContainer
var actions: GridContainer
var portrait_layout := false
var buttons: Array[Button] = []
var dialog: ConfirmationDialog
var objective: LineEdit
var opened := ""
var index := 0
var page_links := false
var current_button := 0
var stored_touch := false
var stored_mouse := Input.MOUSE_MODE_VISIBLE
var pointer_starts: Dictionary = {}
var quest = QUEST.new()
var catalog = CATALOG.new()
var shop = SHOP.new()
var saved_only := false
var shop_dialog: ConfirmationDialog
var shop_name: LineEdit
var shop_description: TextEdit
var shop_price: LineEdit
var shop_edit_index := -1
var shop_remove_dialog: ConfirmationDialog

func install(host: Node3D) -> void:
    world = host
    name = "PlatformTerminals"
    world.add_child(self)
    quest.load_progress()
    catalog.load_favorites()
    shop.load_drafts()
    screen = SubViewport.new()
    screen.size = SIZE
    screen.transparent_bg = true
    screen.disable_3d = true
    screen.render_target_update_mode = SubViewport.UPDATE_DISABLED
    add_child(screen)
    var root := PanelContainer.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var material := StyleBoxFlat.new()
    material.bg_color = Color("071a14f6")
    material.border_color = ACTIVE
    material.set_border_width_all(2)
    material.set_corner_radius_all(18)
    material.content_margin_left = 24
    material.content_margin_right = 24
    material.content_margin_top = 18
    material.content_margin_bottom = 18
    root.add_theme_stylebox_override("panel",material)
    screen.add_child(root)
    layout = VBoxContainer.new()
    layout.add_theme_constant_override("separation",10)
    root.add_child(layout)
    heading = Label.new()
    heading.add_theme_font_size_override("font_size",29)
    heading.add_theme_color_override("font_color",ACTIVE)
    heading.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    layout.add_child(heading)
    body_scroll = ScrollContainer.new()
    body_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    body_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    layout.add_child(body_scroll)
    body = Label.new()
    body.add_theme_font_size_override("font_size",22)
    body.add_theme_color_override("font_color",DORMANT)
    body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    body_scroll.add_child(body)
    actions = GridContainer.new()
    actions.columns = 6
    layout.add_child(actions)
    var plane := QuadMesh.new()
    plane.size = Vector2(4.0,4.0*float(SIZE.y)/float(SIZE.x))
    board = MeshInstance3D.new()
    board.mesh = plane
    var paint := StandardMaterial3D.new()
    paint.albedo_texture = screen.get_texture()
    paint.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    paint.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    paint.cull_mode = BaseMaterial3D.CULL_DISABLED
    board.material_override = paint
    add_child(board)
    board.hide()
    dialog = ConfirmationDialog.new()
    dialog.title = "New Quest objective"
    dialog.ok_button_text = "Save objective"
    objective = LineEdit.new()
    objective.max_length = 80
    objective.placeholder_text = "Enter a local objective"
    objective.custom_minimum_size.x = 255
    dialog.add_child(objective)
    add_child(dialog)
    dialog.confirmed.connect(_save_objective)
    objective.text_submitted.connect(func(_text: String): dialog.hide(); _save_objective())
    _build_shop_dialogs()

func open(app: String) -> void:
    if app not in ["Page","Blog","Quest","Space","Store","Shop","Plus"] or not opened.is_empty():
        return
    var touch: Control = world.get("touch_controls")
    stored_touch = touch.visible
    stored_mouse = Input.mouse_mode
    touch.set_enabled(false)
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
    opened = app
    index = 0
    page_links = false
    saved_only = false
    var camera: Camera3D = world.get("camera")
    var aspect := camera.get_viewport().get_visible_rect().size.aspect()
    var distance := 4.5
    var vertical := distance * tan(deg_to_rad(camera.fov*.5)) * 2.0
    portrait_layout = aspect < 0.8
    actions.columns = 3 if portrait_layout else 6
    heading.add_theme_font_size_override("font_size",34 if portrait_layout else 29)
    body.add_theme_font_size_override("font_size",27 if portrait_layout else 22)
    var scale_factor := minf(1.0,vertical*aspect*(.94 if portrait_layout else .83)/4.0)
    board.global_transform = Transform3D(camera.global_basis.scaled(Vector3.ONE*scale_factor),
        camera.global_position - camera.global_basis.z * distance)
    board.show()
    screen.render_target_update_mode = SubViewport.UPDATE_ALWAYS
    _refresh()

func close() -> void:
    if opened.is_empty():
        return
    opened = ""
    pointer_starts.clear()
    dialog.hide()
    shop_dialog.hide()
    shop_remove_dialog.hide()
    board.hide()
    screen.render_target_update_mode = SubViewport.UPDATE_DISABLED
    world.get("touch_controls").set_enabled(stored_touch)
    Input.mouse_mode = stored_mouse

func content_for(app: String) -> Variant:
    if not CONTENT.has(app):
        return null
    return JSON.parse_string(FileAccess.get_file_as_string(CONTENT[app]))

func _refresh(note := "") -> void:
    for item in actions.get_children():
        actions.remove_child(item)
        item.queue_free()
    buttons.clear()
    current_button = 0
    body_scroll.scroll_vertical = 0
    match opened:
        "Page":
            var profile: Variant = content_for("Page")
            if profile is Dictionary:
                if page_links:
                    _show_page_links(profile)
                else:
                    heading.text = "1AGE Page · " + profile.name
                    body.text = "%s\n%s\n\n%s\n\nPublished demo profile. Account editing and private messaging are unavailable here." % [
                        profile.handle, profile.status, profile.bio,
                    ]
                    _add_button("Profile links",_toggle_page_links)
                    _add_button("Page orbit",_open_3d_application.bind("https://1age.page/profile-orbit.html"))
            else:
                heading.text = "1AGE Page"
                body.text = "Profile data unavailable."
        "Space":
            heading.text = "1AGE Space"
            body.text = "Explore Portland HQ1 or visit the original Sol Road property registry."
            _add_button("Portland HQ1",_open_3d_application.bind("https://1age.space/hq1/"))
            _add_button("Sol Road",_open_sol_road)
        "Blog":
            var articles: Variant = content_for("Blog")
            heading.text = "1AGE Blog"
            if articles is Array and not articles.is_empty():
                var article: Dictionary = articles[index]
                heading.text = article.title
                body.text = "%s  ·  %s\n\n%s" % [article.date,article.status,"\n\n".join(article.body)]
                _cycle_buttons(articles.size())
            else:
                body.text = "Publication catalog unavailable."
            _add_button("Blog exhibits",_open_3d_application.bind("https://1age.blog/application.html"))
        "Store":
            _show_store()
        "Shop":
            _show_shop()
        "Plus":
            heading.text = "1AGE Plus"
            body.text = "Optional membership. Public exploration stays free.\n\nLive enrollment, recurring billing and verified entitlements are not connected. Pricing must be reconciled before activation."
            _add_button("Store",_travel_to_app.bind("Store"))
        "Quest":
            heading.text = "1AGE Quest · Local objectives"
            if quest.items.is_empty():
                body.text = "No saved objectives. Add an objective to track it in this device."
            else:
                var item: Dictionary = quest.items[index]
                body.text = "%d / %d   ·   %s\n\n%s" % [index+1,quest.items.size(),"Complete" if item.done else "Open",item.name]
                _cycle_buttons(quest.items.size())
                _add_button("Reopen" if item.done else "Complete",_toggle_objective)
            _add_button("Add",_edit_objective)
    if not note.is_empty():
        body.text += "\n\n" + note
    _add_button("Back",close)
    actions.columns = mini(3 if portrait_layout else 6,buttons.size())
    _focus(0)

func _show_app_directory() -> void:
    var rows: Array[Dictionary] = catalog.entries(saved_only)
    if rows.is_empty():
        heading.text = "1AGE App · Saved"
        body.text = "No saved apps on this device. Browse the directory to save one."
        _add_button("All apps",_toggle_saved)
        return
    index = clampi(index,0,rows.size()-1)
    var row: Dictionary = rows[index]
    heading.text = row.name + (" · Saved" if saved_only else " · 1AGE App")
    body.text = "%d / %d\n\n%s\n\n%s" % [index+1,rows.size(),row.description,row.url]
    _cycle_buttons(rows.size())
    _add_button("Remove" if row.name in catalog.favorites else "Save",_toggle_favorite.bind(row.name))
    _add_button("Travel",_travel_to_app.bind(row.name))
    _add_button("All apps" if saved_only else "Saved",_toggle_saved)

func _toggle_saved() -> void:
    saved_only = not saved_only
    index = 0
    _refresh()

func _toggle_favorite(name: String) -> void:
    var result: Error = catalog.toggle(name)
    _refresh("" if result == OK else "Could not save changes on this device.")

func _travel_to_app(name: String) -> void:
    var inner: Array = world.get("APPS")
    var index_to_visit := inner.find(name)
    if index_to_visit < 0 and name not in ["Store", "Blog", "Plus"]:
        return
    close()
    if index_to_visit >= 0:
        world.adaptive.activate(name.to_lower())
    else:
        open(name)

func _show_store() -> void:
    var row: Dictionary = CATALOG.OFFERS[index]
    heading.text = row.name
    body.text = "%d / %d  ·  Official offerings\n\n%s\n\n%s" % [index+1,CATALOG.OFFERS.size(),row.description,row.status]
    _cycle_buttons(CATALOG.OFFERS.size())
    if index == 0:
        _add_button("Plus",_travel_to_app.bind("Plus"))
    elif index == 1:
        _add_button("Cash deck",_travel_to_app.bind("Cash"))

func _show_shop() -> void:
    heading.text = "1AGE Shop · Private drafts"
    if shop.items.is_empty():
        body.text = "No drafts on this device. Create a draft listing to prepare a product. Nothing is published and no orders are accepted."
    else:
        index = clampi(index,0,shop.items.size()-1)
        var row: Dictionary = shop.items[index]
        body.text = "%d / %d  ·  Not published\n\n%s\n$%s USD (proposed)\n\n%s" % [index+1,shop.items.size(),row.name,row.price,row.description]
        _cycle_buttons(shop.items.size())
        _add_button("Edit",_edit_shop.bind(index))
        _add_button("Delete",_confirm_shop_remove)
    _add_button("New",_edit_shop.bind(-1))

func _build_shop_dialogs() -> void:
    shop_dialog = ConfirmationDialog.new()
    shop_dialog.title = "Private listing draft"
    shop_dialog.ok_button_text = "Save draft"
    var fields := VBoxContainer.new()
    fields.custom_minimum_size.x = 265
    shop_dialog.add_child(fields)
    shop_name = LineEdit.new()
    shop_name.max_length = 80
    shop_name.placeholder_text = "Product name"
    fields.add_child(shop_name)
    shop_description = TextEdit.new()
    shop_description.placeholder_text = "Description (240 characters max)"
    shop_description.custom_minimum_size.y = 100
    fields.add_child(shop_description)
    shop_price = LineEdit.new()
    shop_price.placeholder_text = "Proposed USD price, e.g. 12.50"
    shop_price.max_length = 12
    fields.add_child(shop_price)
    shop_dialog.confirmed.connect(_save_shop)
    add_child(shop_dialog)
    shop_remove_dialog = ConfirmationDialog.new()
    shop_remove_dialog.title = "Delete local draft?"
    shop_remove_dialog.dialog_text = "This removes the draft from this device."
    shop_remove_dialog.ok_button_text = "Delete"
    shop_remove_dialog.confirmed.connect(_remove_shop)
    add_child(shop_remove_dialog)

func _edit_shop(target: int) -> void:
    shop_edit_index = target
    var row: Dictionary = {} if target < 0 else shop.items[target]
    shop_name.text = row.get("name", "")
    shop_description.text = row.get("description", "")
    shop_price.text = row.get("price", "")
    shop_dialog.popup_centered()
    shop_name.grab_focus()

func _save_shop() -> void:
    if opened != "Shop":
        return
    var result: Error = shop.put(shop_edit_index,shop_name.text,shop_description.text,shop_price.text)
    if result == OK:
        index = shop.items.size()-1 if shop_edit_index == -1 else shop_edit_index
        _refresh("Draft saved on this device only.")
    else:
        _refresh("Enter a product name and a positive USD amount with no more than two decimal places; check storage if valid.")
        shop_dialog.popup_centered()

func _confirm_shop_remove() -> void:
    shop_remove_dialog.popup_centered()

func _remove_shop() -> void:
    if opened != "Shop":
        return
    var result: Error = shop.remove(index)
    index = maxi(0,mini(index,shop.items.size()-1))
    _refresh("" if result == OK else "Could not delete the draft.")

func _dialog_open() -> bool:
    return dialog.visible or shop_dialog.visible or shop_remove_dialog.visible

func _open_3d_application(url: String) -> void:
    close()
    OS.shell_open(url)

func _open_sol_road() -> void:
    close()
    world.call("_enter_native_platform","res://sol_road.tscn")

func _toggle_page_links() -> void:
    page_links = not page_links
    _refresh()

func _show_page_links(profile: Dictionary) -> void:
    var lines := PackedStringArray()
    for row: Dictionary in profile.destinations:
        lines.append(row.name + "  ·  " + row.url)
    heading.text = "1AGE James · Public links"
    body.text = "\n\n".join(lines)
    _add_button("Profile",_toggle_page_links)
    _add_button("Open GitHub",_open_studio_github)
    _add_button("Open Search",_open_oneage_search)

func _open_studio_github() -> void:
    OS.shell_open("https://github.com/1AGEthe3rd")

func _open_oneage_search() -> void:
    OS.shell_open("https://1age.com/")

func _cycle_buttons(count: int) -> void:
    if count > 1:
        _add_button("Previous",_cycle.bind(-1,count))
        _add_button("Next",_cycle.bind(1,count))

func _cycle(step: int, count: int) -> void:
    index = posmod(index + step,count)
    var focus := current_button
    _refresh()
    _focus(focus)

func _edit_objective() -> void:
    objective.clear()
    dialog.popup_centered()
    objective.grab_focus()

func _save_objective() -> void:
    if opened != "Quest":
        return
    var result := quest.add(objective.text)
    if result == OK:
        index = quest.items.size()-1
    _refresh("" if result == OK else "Could not save. Enter an objective and check available storage.")

func _toggle_objective() -> void:
    var result := quest.toggle(index)
    _refresh("" if result == OK else "Could not save. The previous state was kept.")

func _add_button(value: String, callback: Callable) -> void:
    var button := Button.new()
    button.text = value
    button.custom_minimum_size.y = 82 if portrait_layout else 48
    button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    button.add_theme_font_size_override("font_size",25 if portrait_layout else 20)
    button.pressed.connect(callback)
    actions.add_child(button)
    buttons.append(button)

func _focus(target: int) -> void:
    current_button = posmod(target,buttons.size())
    buttons[current_button].grab_focus()

func _command(key: int) -> bool:
    if opened.is_empty() or _dialog_open():
        return false
    match key:
        KEY_ESCAPE: close()
        KEY_LEFT,KEY_UP: _focus(current_button-1)
        KEY_RIGHT,KEY_DOWN,KEY_TAB: _focus(current_button+1)
        KEY_ENTER,KEY_E: buttons[current_button].pressed.emit()
        _: return false
    return true

func _input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo and _command(event.keycode):
        get_viewport().set_input_as_handled()
    elif opened.is_empty() or _dialog_open():
        return
    elif event is InputEventScreenTouch:
        if event.pressed and not event.canceled:
            pointer_starts[event.index] = event.position
        elif pointer_starts.has(event.index):
            var from: Vector2 = pointer_starts[event.index]
            pointer_starts.erase(event.index)
            if not event.canceled and from.distance_to(event.position) < 14.0:
                _click_board(event.position)
        get_viewport().set_input_as_handled()
    elif event is InputEventScreenDrag and pointer_starts.has(event.index):
        if event.position.distance_to(pointer_starts[event.index]) >= 14.0:
            var before := _board_point(event.position-event.relative)
            var after := _board_point(event.position)
            if before.x >= 0.0 and after.x >= 0.0:
                body_scroll.scroll_vertical -= roundi(after.y-before.y)
        get_viewport().set_input_as_handled()
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
        _click_board(event.position)
        get_viewport().set_input_as_handled()
    elif event is InputEventMouseButton and event.pressed and event.button_index in [MOUSE_BUTTON_WHEEL_UP,MOUSE_BUTTON_WHEEL_DOWN]:
        var mapped := _board_point(event.position)
        if mapped.x >= 0.0:
            var wheel := event.duplicate() as InputEventMouseButton
            wheel.position = mapped
            wheel.global_position = mapped
            screen.push_input(wheel,true)
        get_viewport().set_input_as_handled()

func _board_point(point: Vector2) -> Vector2:
    var camera: Camera3D = world.get("camera")
    var intersection: Variant = Plane(board.global_basis.z.normalized(),board.global_position).intersects_ray(camera.project_ray_origin(point),camera.project_ray_normal(point))
    if intersection == null:
        return Vector2(-1,-1)
    var local := board.to_local(intersection)
    var uv := Vector2(local.x / 4.0 + .5,.5 - local.y / (4.0 * float(SIZE.y) / float(SIZE.x)))
    return uv * Vector2(SIZE) if Rect2(Vector2.ZERO,Vector2.ONE).has_point(uv) else Vector2(-1,-1)

func _click_board(point: Vector2) -> void:
    var mapped := _board_point(point)
    if mapped.x < 0.0:
        return
    for i in range(buttons.size()):
        if buttons[i].get_global_rect().has_point(mapped):
            buttons[i].pressed.emit()
            return

func consume_controller(pressed: Array[bool],prior: Array[bool]) -> bool:
    if opened.is_empty():
        return false
    if pressed[JOY_BUTTON_B] and not prior[JOY_BUTTON_B]:
        if shop_remove_dialog.visible:
            shop_remove_dialog.hide()
        elif shop_dialog.visible:
            shop_dialog.hide()
        elif dialog.visible:
            dialog.hide()
        else:
            close()
        return true
    if _dialog_open():
        return true
    for key in [[JOY_BUTTON_DPAD_LEFT,KEY_LEFT],[JOY_BUTTON_DPAD_RIGHT,KEY_RIGHT],[JOY_BUTTON_A,KEY_ENTER],[JOY_BUTTON_X,KEY_E]]:
        if pressed[key[0]] and not prior[key[0]]:
            _command(key[1])
            break
    return true
