extends RefCounted
## Native World directory and local-only saved app selection.
## URLs are existing 1AGE domains from the release record; no unverified hosts.
const DEFAULT_PATH := "user://world-app-favorites.json"
const APPS := [
    {"name":"Page","description":"3D social profile and public links. Account editing and messaging are not connected.","url":"https://1age.page/"},
    {"name":"Space","description":"Independent virtual-space and commercial-property platform. Visit HQ1 Portland or the separate Sol Road prototype.","url":"https://1age.space/"},
    {"name":"Games","description":"Native Games complex and playable experiences.","url":"https://1age.games/"},
    {"name":"Quest","description":"Local saved objectives. Synced missions and rewards are not connected.","url":"https://1age.quest/"},
    {"name":"Exchange","description":"Existing read-only wallet viewer. Transfers, swaps and payments are not enabled here.","url":"https://1age.exchange/"},
    {"name":"Design","description":"Native creator tools on the expanding Design platform.","url":"https://1age.design/"},
    {"name":"Work","description":"Geographic work and contribution discovery. No connected job feed.","url":"https://1age.work/"},
    {"name":"Forum","description":"Local and global community discovery. No live posts connected.","url":"https://1age.forum/"},
    {"name":"Cash","description":"Internal credits and earning/use categories. No live financial services.","url":"https://1age.cash/"},
    {"name":"Blog","description":"Existing article catalog and exhibits.","url":"https://1age.blog/"},
    {"name":"Store","description":"Official 1AGE offerings. Catalog inspection; no live purchasing.","url":"https://1age.store/"},
    {"name":"Shop","description":"Marketplace platform. Private local seller drafts only; no published marketplace listings.","url":"https://1age.shop/"},
    {"name":"Plus","description":"Optional membership. Free exploration remains available. Live enrollment is not connected.","url":"https://1age.plus/"},
]
const OFFERS := [
    {"name":"1AGE Plus","description":"Optional membership. Public exploration remains free. Billing terms and verified benefits are not activated.","status":"Store lists $1/month; the separate Plus test checkout lists $3.33/month. Pricing needs reconciliation before enrollment."},
    {"name":"1AGE Cash","description":"Internal account-based credits for eligible 1AGE experiences, distinct from the proposed $1AGE cryptocurrency.","status":"Credit sales, redemption and cash-out are not enabled in this build."},
    {"name":"Virtual Checkout","description":"Existing nonfinancial checkout simulation. No merchandise or live inventory is offered.","status":"No live orders or payments are available here."},
]
var path := DEFAULT_PATH
var favorites: Array[String] = []

func has_app(name: String) -> bool:
    for row: Dictionary in APPS:
        if row.name == name:
            return true
    return false

func load_favorites() -> void:
    favorites.clear()
    if not FileAccess.file_exists(path):
        return
    var data: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
    if not data is Array:
        return
    for row: Variant in data:
        if row is String and has_app(row) and row not in favorites:
            favorites.append(row)

func entries(saved_only: bool) -> Array[Dictionary]:
    var result: Array[Dictionary] = []
    for row: Dictionary in APPS:
        if not saved_only or row.name in favorites:
            result.append(row.duplicate())
    return result

func toggle(name: String) -> Error:
    if not has_app(name):
        return ERR_INVALID_PARAMETER
    var previous: Array[String] = favorites.duplicate()
    if name in favorites:
        favorites.erase(name)
    else:
        favorites.append(name)
    var result := save_json(path,favorites)
    if result != OK:
        favorites = previous
    return result

static func save_json(target: String, data: Variant) -> Error:
    var temporary := target + ".tmp"
    var file := FileAccess.open(temporary,FileAccess.WRITE)
    if file == null:
        return FileAccess.get_open_error()
    file.store_string(JSON.stringify(data))
    file.flush()
    var result := file.get_error()
    file.close()
    if result == OK:
        result = DirAccess.rename_absolute(temporary,target)
    if result != OK:
        DirAccess.remove_absolute(temporary)
    return result
