extends Node3D
# Local vehicle state; no network, inventory or payment changes.
const GLOW := Color("1BFD9C")
var world: Node3D
var cockpit: Node3D
var hull: Node3D
var lamps: Node3D
var speed_gauge: MeshInstance3D
var parked := false
var lights_on := true
var landing := false
var landed := false
var landing_target := Vector3.ZERO
var parked_at := Vector3.ZERO
var parked_yaw := 0.0

func install(host: Node3D) -> void:
    world = host
    name = "PersonalSpaceship"
    host.add_child(self)
    cockpit = Node3D.new()
    cockpit.name = "PilotCockpit"
    world.camera.add_child(cockpit)
    # Camera-relative physical cockpit, kept low with an open central viewport.
    _box(cockpit, Vector3(0,-0.64,-1.15), Vector3(2.5,.19,.9), Color("111c28"))
    for side in [-1.0,1.0]:
        _box(cockpit,Vector3(side*1.0,-.28,-1.20),Vector3(.13,.95,.15),Color("223242"),Vector3(0,0,side*.30))
        _box(cockpit,Vector3(side*.71,-.52,-.94),Vector3(.45,.10,.50),Color("1d3440"),Vector3(-.15,0,side*.08))
        _box(cockpit,Vector3(side*.71,-.455,-1.00),Vector3(.34,.013,.24),Color("105c53"))
        for j in range(4):
            _box(cockpit,Vector3(side*.71+(j-1.5)*.075,-.442,-1.0),Vector3(.042,.01,.12),GLOW,Vector3.ZERO,true)
    _box(cockpit,Vector3(0,-.49,-1.42),Vector3(.80,.12,.09),Color("12352e"))
    speed_gauge = _box(cockpit,Vector3(0,-.476,-1.36),Vector3(.68,.045,.018),GLOW,Vector3.ZERO,true)
    hull = Node3D.new()
    hull.name = "ParkedShip"
    add_child(hull)
    _box(hull,Vector3(0,.65,0),Vector3(2.5,1.15,4.2),Color("21303c"))
    _box(hull,Vector3(0,1.35,-.35),Vector3(1.55,.45,1.75),Color("21566b"))
    for side in [-1.0,1.0]:
        _box(hull,Vector3(side*1.65,.50,.40),Vector3(1.5,.25,2.7),Color("344657"),Vector3(0,side*.18,0))
        _box(hull,Vector3(side*.85,.65,2.12),Vector3(.43,.38,.07),GLOW,Vector3.ZERO,true)
    lamps = Node3D.new()
    lamps.name = "FlightHeadlamps"
    world.camera.add_child(lamps)
    for side in [-1.0,1.0]:
        var lamp := Node3D.new()
        lamps.add_child(lamp)
        lamp.position = Vector3(side*.70,-.42,-1.25)
        lamp.rotation.y = -side*.055
        add_beam(lamp, 32.0, 5.8, Color(.64,.86,1.0,.13))
    sync()

func _box(parent: Node3D, at: Vector3, size: Vector3, tint: Color, angles: Vector3 = Vector3.ZERO, bright: bool = false) -> MeshInstance3D:
    var instance := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = size
    instance.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = tint
    mat.metallic = .35
    mat.roughness = .33
    if bright:
        mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        mat.emission_enabled = true
        mat.emission = tint
    instance.material_override = mat
    parent.add_child(instance)
    instance.position = at
    instance.rotation = angles
    return instance

static func add_beam(parent: Node3D, length: float, radius: float, tint: Color) -> void:
    # Compatibility-renderer approximation to volumetric dust scattering.
    # Actual spotlight illuminates nearby surfaces; transparent cones show the beam.
    var light := SpotLight3D.new()
    light.spot_range = length
    light.spot_angle = rad_to_deg(atan(radius/length)) + 4.0
    light.light_color = Color(tint.r,tint.g,tint.b)
    light.light_energy = 2.2
    light.shadow_enabled = false
    parent.add_child(light)
    for i in range(3):
        var beam := MeshInstance3D.new()
        var mesh := CylinderMesh.new()
        mesh.top_radius = .06
        mesh.bottom_radius = radius * (1.0-float(i)*.23)
        mesh.height = length
        mesh.radial_segments = 18
        mesh.rings = 1
        beam.mesh = mesh
        var mat := ShaderMaterial.new()
        var shader := Shader.new()
        shader.code = """shader_type spatial;
render_mode unshaded, blend_add, depth_draw_never, cull_disabled, shadows_disabled;
uniform vec4 tint : source_color;
uniform float beam_length;
varying float axial;
void vertex(){axial=clamp(0.5-VERTEX.y/beam_length,0.0,1.0);}
void fragment(){
    float edge=pow(abs(dot(normalize(NORMAL),normalize(VIEW))),1.8);
    float fade=smoothstep(0.0,0.10,axial)*(1.0-smoothstep(0.32,1.0,axial));
    ALBEDO=tint.rgb;
    ALPHA=tint.a*edge*fade;
}"""
        mat.shader = shader
        mat.set_shader_parameter("beam_length",length)
        mat.set_shader_parameter("tint",Color(tint.r,tint.g,tint.b,tint.a/(1.8+float(i)*1.4)))
        beam.material_override = mat
        beam.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        parent.add_child(beam)
        beam.rotation.x = PI/2
        beam.position.z = -length/2

func aboard() -> bool:
    return world.movement.mode == world.movement.Mode.SHIP

func sync() -> void:
    var inspection: bool = is_instance_valid(world.adaptive) and world.adaptive.inspection
    cockpit.visible = aboard() and not inspection
    lamps.visible = cockpit.visible and lights_on
    hull.visible = parked and not aboard()
    speed_gauge.scale.x = maxf(.05,clampf(world.player.velocity.length()/42.0,0.0,1.0))
    world.touch_controls.ship_parked_near = can_board()
    world.touch_controls.ship_lights = lights_on
    world.touch_controls.ship_landing = landing
    world.touch_controls.ship_landed = landed

func reset() -> void:
    parked = false
    landing = false
    landed = false
    sync()

func can_board() -> bool:
    return parked and not aboard() and world.player.global_position.distance_to(parked_at) < 6.0

func toggle_lights() -> void:
    if aboard(): lights_on = not lights_on
    sync()

func park_at(at: Vector3, yaw: float) -> void:
    parked = true
    parked_at = at
    parked_yaw = yaw
    hull.global_position = at
    hull.rotation.y = yaw

func board_or_land() -> void:
    if aboard():
        if landed:
            var yaw: float = world.player.rotation.y
            park_at(world.player.global_position,yaw)
            var outward := Vector3(parked_at.x,0,parked_at.z).normalized()
            world.player.global_position = parked_at + outward*3.3
            world.player.look_at(Vector3(parked_at.x,world.player.position.y,parked_at.z),Vector3.UP)
            world.movement.mode = world.movement.Mode.WALK
            world.camera.rotation.x = 0.0
            world.player.velocity = Vector3.ZERO
            landed = false
            world.touch_controls.reset_controls()
        elif landing:
            landing = false
            world.player.velocity = Vector3.ZERO
        else:
            request_landing()
    elif can_board():
        world.player.global_position = parked_at + Vector3.UP*1.5
        world.player.rotation.y = parked_yaw
        world.camera.rotation.x = 0.0
        world.movement.mode = world.movement.Mode.SHIP
        world.player.velocity = Vector3.ZERO
        parked = false
        world.touch_controls.reset_controls()
    sync()

func request_landing() -> bool:
    # Only land on existing platform geometry, never in empty space.
    var at: Vector3 = world.player.global_position
    var best := 16.0
    var chosen := Vector3.ZERO
    for center in world.app_centers:
        var distance := Vector2(at.x-center.x,at.z-center.z).length()
        if distance < best:
            best = distance
            var outward := Vector3(center.x,0,center.z).normalized()
            chosen = center - outward*7.0 + Vector3.UP*.35
    if best >= 16.0 or at.y < world.DECK_Y-1.0 or at.y > world.DECK_Y+28.0:
        return false
    landing_target = chosen
    landing = true
    world.touch_controls.reset_controls()
    world.player.velocity = Vector3.ZERO
    return true

func tick(delta: float, active: bool) -> bool:
    if not aboard():
        landing = false
        landed = false
    sync()
    if landed:
        world.player.velocity = Vector3.ZERO
        if active and (world.touch_controls.vertical_axis > .2 or Input.is_action_pressed("fly_up")):
            landed = false
            world.player.position.y += 1.5
            return false
        return true
    if not landing: return false
    if not active: return true
    var at: Vector3 = world.player.global_position
    # First align above the deck, then descend at limited speed.
    var target := landing_target + Vector3.UP*3.4
    if Vector2(at.x-target.x,at.z-target.z).length() < .18:
        target = landing_target
    var next := at.move_toward(target, minf(6.0*delta,at.distance_to(target)))
    world.player.global_position = next
    world.player.velocity = Vector3.ZERO
    if next.distance_to(landing_target) < .12:
        world.player.global_position = landing_target
        landing = false
        landed = true
        world.touch_controls.reset_controls()
        sync()
    return true
