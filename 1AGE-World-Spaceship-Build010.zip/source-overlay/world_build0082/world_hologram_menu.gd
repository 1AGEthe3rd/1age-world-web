extends Node3D

const ACTIVE := Color("1BFD9C")
const DORMANT := Color("E2FFDC")
const NEAR_DISTANCE := 17.0

var world: Node3D
var panel: PanelContainer
var buttons: Array[Button] = []
var touch_starts: Dictionary = {}
var logo: Sprite3D
var search_icon: Sprite3D
var crown: Node3D
var beacons: Array[Node3D] = []
var menu_icons: Array[Sprite3D] = []
var expanded := false
var expansion := 0.0
var social_open := false
var social_icon: Sprite3D
var settings_icon: Sprite3D
var search_field: LineEdit
var search_point := Vector2.ZERO
var logo_point := Vector2.ZERO
var logo_radius := 34.0
var beacon_clock := 0.0
var pressed_target := 0
var had_touch_controls := false
var previous_mouse := Input.MOUSE_MODE_VISIBLE

func install(host: Node3D, layer: CanvasLayer) -> void:
    world = host
    name = "WorldHologramMenu"
    host.add_child(self)
    crown = Node3D.new()
    crown.name = "EarthCrown"
    add_child(crown)
    crown.global_position = world.earth.global_position + Vector3.UP*29.0
    logo = _sky_sprite("UniversalRoundMenuLogo", preload("res://world_build0082/homepage_icons/menu-logo.png"),8.6)
    logo.position.y = 6.2
    search_icon = _sky_sprite("UniversalSearchIcon",preload("res://world_build0082/homepage_icons/search-control.png"),5.2)
    search_icon.position.y = -.1
    var paths := ["M12 24h40l-4 30H16z M22 24v-7a10 10 0 0 1 20 0v7", "M12 12h40v40H12z M20 23h24M20 32h24M20 41h16", "M32 12v40M12 32h40", "M32 12a9 9 0 1 0 .01 0 M12 52c2-21 38-21 40 0"]
    for i in range(paths.size()):
        var item := _sky_sprite(["Store","Blog","Plus","Social"][i],_icon_texture(paths[i]),5.6)
        menu_icons.append(item)
        item.hide()
    social_icon = _sky_sprite("SocialGitHub",_icon_texture("M20 20l-4 -9 10 5a22 22 0 0 1 12 0l10 -5 -4 9c9 14 1 26-12 26S11 34 20 20z M25 46v8 M39 46v8"),4.2)
    social_icon.hide()
    settings_icon = _sky_sprite("Settings",_icon_texture("M32 20a12 12 0 1 0 .01 0 M32 7v9 M32 48v9 M7 32h9 M48 32h9 M14 14l6 6 M44 44l6 6 M50 14l-6 6 M20 44l-6 6"),2.8)
    settings_icon.position.y = -.1
    settings_icon.hide()
    for side in [-1.0,1.0]:
        var pivot := Node3D.new()
        crown.add_child(pivot)
        pivot.position=Vector3(side*9.0,-5.0,0)
        preload("res://world_build0082/ship_vehicle.gd").add_beam(pivot,34.0,4.8,Color(.44,.81,1.0,.32))
        beacons.append(pivot)
    _build_panel(layer)

func _icon_texture(path: String) -> Texture2D:
    var img := Image.new()
    var svg := '<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128" viewBox="0 0 64 64"><circle cx="32" cy="32" r="30" fill="#061b17" stroke="#1bfd9c" stroke-width="1.5"/><path d="'+path+'" fill="none" stroke="#b5ffe0" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>'
    img.load_svg_from_string(svg)
    return ImageTexture.create_from_image(img)

func _sky_sprite(node_name: String, tex: Texture2D, width: float) -> Sprite3D:
    var sprite := Sprite3D.new()
    sprite.name = node_name
    sprite.texture = tex
    sprite.shaded = false
    sprite.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    sprite.pixel_size = width / float(tex.get_width())
    sprite.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    crown.add_child(sprite)
    return sprite

func _process(delta: float) -> void:
    beacon_clock += delta
    if not is_instance_valid(crown): return
    var camera: Camera3D = world.camera
    # Crown stays at the globe's north, not at a fixed screen location. Horizontal
    # orientation follows the observer so the menu wings remain readable.
    var offset := camera.global_position - crown.global_position
    if Vector2(offset.x,offset.z).length() > .01:
        crown.rotation.y = atan2(offset.x,offset.z)
    expansion = move_toward(expansion,1.0 if expanded else 0.0,delta*3.8)
    var eased := smoothstep(0.0,1.0,expansion)
    for i in range(menu_icons.size()):
        var item := menu_icons[i]
        item.position = Vector3([-17.0,-8.5,8.5,17.0][i]*eased,6.2,0)
        item.visible = expansion > .01 and not social_open
        item.modulate.a = eased
    social_icon.position = Vector3(8.5*eased,6.2,0)
    social_icon.visible = expanded and social_open
    settings_icon.position.x = 5.5*eased
    settings_icon.visible = expanded
    for i in range(beacons.size()):
        var side := -1.0 if i==0 else 1.0
        beacons[i].rotation = Vector3(PI*.47+sin(beacon_clock*.37+i*1.8)*.22,0,side*.36+sin(beacon_clock*.29+i)*.26)

func _build_panel(layer: CanvasLayer) -> void:
    panel = PanelContainer.new()
    panel.name = "SharedSettings"
    var material := StyleBoxFlat.new()
    material.bg_color = Color("041610ef")
    material.border_color = ACTIVE
    material.set_border_width_all(1)
    material.set_corner_radius_all(16)
    material.content_margin_left = 15
    material.content_margin_right = 15
    material.content_margin_top = 10
    material.content_margin_bottom = 12
    panel.add_theme_stylebox_override("panel", material)
    layer.add_child(panel)
    var scroll := ScrollContainer.new()
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    scroll.follow_focus = true
    panel.add_child(scroll)
    var list := VBoxContainer.new()
    list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    scroll.add_child(list)
    _heading(list, "1AGE WORLD")
    _button(list,"Resume",close)
    search_field = LineEdit.new()
    search_field.placeholder_text = "Search 1AGE"
    search_field.custom_minimum_size.y = 38
    search_field.text_submitted.connect(_submit_search)
    list.add_child(search_field)
    _button(list,"Search",func(): _submit_search(search_field.text))
    _heading(list,"Controls")
    _button(list,"Toggle touch gamepad",_toggle_touch)
    _button(list,"Toggle walk / flight",_toggle_flight)
    _button(list,"Show controls manual",_show_controls_manual)
    _button(list,"Main arrival",_go_home)
    _button(list,"Return to World mode",_world_mode)
    _button(list,"Explore Space globe",_space_globe)
    _button(list,"Explore Cash opportunities",_cash_mode)
    _heading(list,"Applications")
    for app in world.APPS:
        _button(list,app,_activate_app.bind(app.to_lower()))
    _heading(list,"1AGE")
    var services := HBoxContainer.new()
    list.add_child(services)
    for app in ["Store", "Blog", "Plus"]:
        _button(services,app,_open_service.bind(app))
    _button(list,"Return to 1AGE.com",_open_homepage)
    _button(list,"1AGE on GitHub",_open_github)
    get_viewport().size_changed.connect(_layout)
    _layout()
    panel.hide()

func _layout() -> void:
    var size := get_viewport().get_visible_rect().size
    var panel_size := Vector2(minf(340,size.x-24),minf(510,size.y-38))
    panel.size = panel_size
    panel.position = (size - panel_size) * .5

func _heading(parent: Control, title: String) -> void:
    var label := Label.new()
    label.text = title
    label.add_theme_color_override("font_color", DORMANT)
    parent.add_child(label)

func _button(parent: Control, title: String, callback: Callable) -> void:
    var button := Button.new()
    button.text = title
    button.custom_minimum_size.y = 38
    button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    button.pressed.connect(callback)
    parent.add_child(button)
    buttons.append(button)

func is_open() -> bool:
    return is_instance_valid(panel) and panel.visible

func open() -> void:
    if is_open() or world.call("terminal_active"):
        return
    var tools := get_node_or_null("/root/OneAGEDesign")
    if tools != null and tools.get("editing"):
        return
    var touch: Control = world.get("touch_controls")
    had_touch_controls = touch.visible
    previous_mouse = Input.mouse_mode
    touch.set_enabled(false)
    world.get("player").velocity = Vector3.ZERO
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
    _set_sky_visible(false)
    panel.show()
    buttons[0].grab_focus()

func close() -> void:
    if not is_open():
        return
    panel.hide()
    _set_sky_visible(true)
    touch_starts.clear()
    world.get("touch_controls").set_enabled(had_touch_controls)
    Input.mouse_mode = previous_mouse

func toggle() -> void:
    if is_open():
        close()
    else:
        open()

func consume_controller(pressed: Array[bool], prior: Array[bool]) -> bool:
    if not is_open():
        if _edge(pressed,prior,JOY_BUTTON_START):
            open()
            return is_open()
        return false
    if _edge(pressed,prior,JOY_BUTTON_START) or _edge(pressed,prior,JOY_BUTTON_B):
        close()
        return true
    var focused := get_viewport().gui_get_focus_owner()
    var index := maxi(0,buttons.find(focused))
    if _edge(pressed,prior,JOY_BUTTON_DPAD_DOWN):
        buttons[posmod(index+1,buttons.size())].grab_focus()
    elif _edge(pressed,prior,JOY_BUTTON_DPAD_UP):
        buttons[posmod(index-1,buttons.size())].grab_focus()
    elif _edge(pressed,prior,JOY_BUTTON_A):
        buttons[index].pressed.emit()
    return true

func _edge(pressed: Array[bool], prior: Array[bool], button: int) -> bool:
    return pressed[button] and not prior[button]

func _input(event: InputEvent) -> void:
    if not is_instance_valid(panel):
        return
    if event is InputEventKey and event.pressed and not event.echo:
        if (event.keycode == KEY_M and not (is_open() and search_field.has_focus())) or (is_open() and event.keycode == KEY_ESCAPE):
            toggle()
            get_viewport().set_input_as_handled()

# Called by the existing touch layer before its generic screen capture.
func consume_pointer(event: InputEvent) -> bool:
    if not is_instance_valid(panel) or is_open():
        return false
    if event is InputEventScreenDrag and touch_starts.has(event.index):
        var start: Dictionary = touch_starts[event.index]
        if event.position.distance_to(start.point) > 12.0:
            start.target = 0
        return true
    if event is InputEventScreenTouch:
        var target := _hit_target(event.position)
        if event.pressed and not event.canceled and target != 0:
            touch_starts[event.index] = {"point": event.position, "target": target}
            return true
        if not event.pressed and touch_starts.has(event.index):
            var start: Dictionary = touch_starts[event.index]
            touch_starts.erase(event.index)
            if not event.canceled and target != 0 and target == start.target:
                _activate_target(target)
            return true
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
        var point: Vector2 = event.position if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED else get_viewport().get_visible_rect().get_center()
        var target := _hit_target(point)
        if target != 0:
            _activate_target(target)
            return true
    return false

func _set_sky_visible(enabled: bool) -> void:
    crown.visible = enabled
    if not enabled:
        expanded = false
        social_open = false

func _sprite_hit(sprite: Sprite3D, point: Vector2) -> bool:
    var camera: Camera3D = world.camera
    if not sprite.is_visible_in_tree() or camera.is_position_behind(sprite.global_position): return false
    var center := camera.unproject_position(sprite.global_position)
    var edge := camera.unproject_position(sprite.global_position+camera.global_basis.x*sprite.pixel_size*float(sprite.texture.get_width())*.5)
    return point.distance_to(center) <= maxf(14.0,center.distance_to(edge))

func _hit_target(point: Vector2) -> int:
    if _sprite_hit(logo,point): return 1
    if _sprite_hit(search_icon,point): return 2
    for i in range(menu_icons.size()):
        if _sprite_hit(menu_icons[i],point): return 3+i
    if _sprite_hit(social_icon,point): return 7
    if _sprite_hit(settings_icon,point): return 8
    return 0

func _hologram_hit(point: Vector2) -> bool:
    return _hit_target(point) != 0

func _activate_target(target: int) -> void:
    match target:
        1:
            if social_open: social_open = false
            else: expanded = not expanded
        2:
            open()
            if is_open(): search_field.grab_focus()
        3,4,5:
            expanded = false
            _open_service(["Store","Blog","Plus"][target-3])
        6: social_open = true
        7: _open_github()
        8: open()

func _submit_search(value: String) -> void:
    var query := value.strip_edges()
    if query.is_empty():
        search_field.grab_focus()
        return
    close()
    if is_instance_valid(world.adaptive) and world.adaptive.mode != "world":
        world.adaptive.show_search(query)
        return
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
    OS.shell_open("https://1age.com/?q=" + query.uri_encode())

func _toggle_touch() -> void:
    had_touch_controls = not had_touch_controls
    close()

func _toggle_flight() -> void:
    world._touch_command("fly")
    close()

func _show_controls_manual() -> void:
    close()
    world.get("room_ui").set_manual(true)

func _go_home() -> void:
    close()
    world.reset_ship_arrival()

func _travel_to(index: int) -> void:
    close()
    world.call("_place_at_platform", index)

func _open_service(app: String) -> void:
    close()
    world.get("platform_terminals").open(app)

func _open_homepage() -> void:
    close()
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
    OS.shell_open("https://1age.com/")

func _open_github() -> void:
    close()
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
    OS.shell_open("https://github.com/1AGEthe3rd")

func _world_mode() -> void:
    close()
    world.adaptive.activate("world")

func _space_globe() -> void:
    close()
    if world.adaptive.mode != "space": world.adaptive.activate("space")
    world.adaptive.start_inspection()

func _cash_mode() -> void:
    close()
    world.adaptive.activate("cash")

func _activate_app(app: String) -> void:
    close()
    world.adaptive.activate(app)
