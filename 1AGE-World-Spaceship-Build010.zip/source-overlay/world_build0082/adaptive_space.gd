extends Node3D
# Shared mode contract: one ring, mutable platform roles, contextual search and ticker.
const ROLES := ["HQ1", "HQ2", "Cities", "Properties", "Businesses", "Districts", "Build", "Claims", "Creator Spaces", "Transit"]
const ICONS := ["space", "space", "quest", "space", "shop", "forum", "design", "page", "design", "exchange"]
const CATALOG := "https://1age.space/catalog.html"
const GREEN := Color("1BFD9C")
const CASH := preload("res://world_build0082/cash_opportunities.gd")
var modes: Dictionary = {}
var personal_page := false
var world: Node3D
var mode := "world"
var seed: Dictionary = {}
var markers: Dictionary = {}
var ticker: Label
var panel: PanelContainer
var list: VBoxContainer
var input: LineEdit
var saved_touch := false
var saved_mouse := Input.MOUSE_MODE_VISIBLE
var selected_city := ""
var matches: Array = []
var marker_counts: Dictionary = {}
var pointer := {}
var target_rotation := Vector3.ZERO
var focusing := false
var inspection := false
var previous_fov := 78.0
var previous_camera := Transform3D.IDENTITY
var previous_heading := 0.0
var inspection_touch := false
var inspection_mouse := Input.MOUSE_MODE_VISIBLE
var mouse_drag := false
var mouse_start := Vector2.ZERO
var mouse_moved := false
var selected_label: Label
var clock := 0.0
var ticker_index := -1
var result_note := ""
var zoom_row: HBoxContainer

func install(host: Node3D, layer: CanvasLayer) -> void:
    world = host
    name = "AdaptiveApplications"
    host.add_child(self)
    var parsed = JSON.parse_string(FileAccess.get_file_as_string("res://world_build0082/platforms/space_seed.json"))
    if parsed is Dictionary: seed = parsed
    var config = JSON.parse_string(FileAccess.get_file_as_string("res://world_build0082/platforms/adaptive_modes.json"))
    if config is Dictionary: modes = config
    ticker = Label.new()
    ticker.name = "AdaptiveTicker"
    ticker.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    ticker.add_theme_color_override("font_color",GREEN)
    ticker.add_theme_font_size_override("font_size",16)
    ticker.mouse_filter = Control.MOUSE_FILTER_IGNORE
    layer.add_child(ticker)
    ticker.hide()
    zoom_row = HBoxContainer.new()
    layer.add_child(zoom_row)
    for item in [["−",func(): zoom(1.15)],["+",func(): zoom(.87)],["Close globe",stop_inspection]]:
        var b := Button.new()
        b.text = item[0]
        b.custom_minimum_size = Vector2(44,40)
        b.pressed.connect(item[1])
        zoom_row.add_child(b)
    zoom_row.hide()
    selected_label=Label.new()
    selected_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
    selected_label.add_theme_color_override("font_color",Color.WHITE)
    selected_label.add_theme_font_size_override("font_size",18)
    selected_label.mouse_filter=Control.MOUSE_FILTER_IGNORE
    layer.add_child(selected_label)
    selected_label.hide()
    panel = PanelContainer.new()
    var style := StyleBoxFlat.new()
    style.bg_color = Color("06130ff5")
    style.border_color = GREEN
    style.set_border_width_all(1)
    style.set_corner_radius_all(12)
    style.content_margin_left = 12
    style.content_margin_right = 12
    style.content_margin_top = 12
    style.content_margin_bottom = 12
    panel.add_theme_stylebox_override("panel",style)
    layer.add_child(panel)
    var scroll := ScrollContainer.new()
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    panel.add_child(scroll)
    list = VBoxContainer.new()
    list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    scroll.add_child(list)
    panel.hide()
    get_viewport().size_changed.connect(layout)
    layout()

func layout() -> void:
    var size := get_viewport().get_visible_rect().size
    ticker.position = Vector2(12,size.y-35)
    ticker.size = Vector2(size.x-24,30)
    ticker.add_theme_font_size_override("font_size",12 if size.x<600 else 16)
    panel.size = Vector2(minf(520,size.x-24),minf(530,size.y-40))
    panel.position = (size-panel.size)*.5
    zoom_row.position = Vector2((size.x-zoom_row.size.x)*.5, size.y-104)
    selected_label.position=Vector2(12, size.y-148)
    selected_label.size=Vector2(size.x-24,32)

func role(index: int) -> String:
    if mode == "space": return ROLES[index]
    if modes.has(mode): return str(mode_roles()[index].name)
    return world.APPS[index]

func activate(requested: String) -> bool:
    if requested not in ["world","space","cash"] and not modes.has(requested): return false
    close_panel()
    stop_inspection()
    mode = requested
    personal_page = false
    selected_city = ""
    result_note = ""
    ticker_index = -1
    world.console_active = false
    world.dock_idx = -1
    world.platform_touches.clear()
    for i in range(world.APPS.size()):
        var app: String = world.APPS[i]
        var sign: MeshInstance3D = world.find_child("3D_"+app.to_upper(),true,false)
        var icon: Sprite3D = world.find_child("HomepageIcon_"+app,true,false)
        if sign == null or icon == null: continue
        var text_mesh := sign.mesh as TextMesh
        text_mesh.text = role(i).to_upper()
        text_mesh.pixel_size = 0.047
        if text_mesh.get_aabb().size.x > 5.8: text_mesh.pixel_size *= 5.8/text_mesh.get_aabb().size.x
        var tint := GREEN if mode=="space" else (Color(world.APP_COLORS[world.APPS.find(mode.capitalize())]) if modes.has(mode) else Color(world.APP_COLORS[i]))
        var mat := sign.material_override as StandardMaterial3D
        mat.albedo_color = tint
        mat.emission = tint
        icon.texture = load("res://world_build0082/homepage_icons/"+(ICONS[i] if mode=="space" else (str(mode_roles()[i].icon) if modes.has(mode) else app.to_lower()))+".png")
        icon.pixel_size = 6.2/float(icon.texture.get_height())
    if is_instance_valid(world.world_orbit_title): world.world_orbit_title.mesh.text = mode_title()
    world.world_menu.search_field.placeholder_text = "Search spaces, cities, properties" if mode=="space" else ("Search Cash earning and use categories" if mode=="cash" else "Search 1AGE")
    if modes.has(mode): world.world_menu.search_field.placeholder_text = str(modes[mode].placeholder)
    ticker.visible = mode!="world"
    if mode=="space": search("")
    elif mode=="cash": cash_search("")
    elif modes.has(mode): generic_search("")
    else:
        clear_markers()
        if is_instance_valid(world.world_orbit_title): world.world_orbit_title.show()
    return true

func mode_title() -> String:
    return "My Page" if mode=="page" and personal_page else "1AGE "+mode.capitalize()

func cash_search(query: String) -> Array:
    matches=CASH.search(query)
    marker_counts.clear()
    clear_markers()
    result_note=str(matches.size())+" planned categories · 0 published offers in this build"
    return matches

func show_cash_search(query: String="") -> void:
    cash_search(query)
    begin_panel("1AGE CASH / OPPORTUNITIES")
    input=LineEdit.new()
    input.placeholder_text="App, activity or pilot city"
    input.text=query
    input.text_submitted.connect(show_cash_search)
    list.add_child(input)
    button("Search Cash categories",func(): show_cash_search(input.text))
    line(result_note)
    line(CASH.DISCLAIMER,13)
    for item in matches:
        button(str(item.app)+" · Earn / Use",open_cash_role.bind(world.APPS.find(item.app)))
    if matches.is_empty(): line("No matching categories in this preview.")
    line("Explore pilot locations (not opportunity markers)",14)
    button("Focus Portland · HQ1",focus_city.bind("Portland"))
    button("Focus Washington, D.C. · HQ2",focus_city.bind("Washington, D.C."))
    button("Return to World mode",func(): activate("world"))

func open_cash_role(index: int) -> void:
    if index<0 or index>=CASH.ITEMS.size(): return
    var item: Dictionary=CASH.ITEMS[index]
    begin_panel("1AGE CASH / "+str(item.app).to_upper())
    line("EARN",16)
    line(str(item.earn))
    line("USE",16)
    line(str(item.use))
    line(CASH.DISCLAIMER,13)
    if item.app=="Work": line("Internal credits are not a substitute for legally required wages.",13)
    if item.app=="Cash":
        line("Secure balance is not connected to this World preview. Use the existing Cash account portal for sign-in; no account or ledger changes are made here.",14)
        button("Open existing Cash account portal",open_cash_account)
    else:
        link("Explore 1AGE "+str(item.app),"https://1age."+str(item.app).to_lower()+"/")
    button("Browse Cash categories",show_cash_search.bind(""))
    button("Return to World mode",func(): activate("world"))

func open_cash_account() -> void:
    close_panel()
    # The existing Cash parent page supplies its own account controls. Open in a separate tab, not in the iframe.
    OS.shell_open("https://1age.cash/")

func normalize(value: String) -> String:
    var s := value.to_lower()
    for character in [".",",","·","-","/"]: s = s.replace(character," ")
    return " ".join(s.split(" ",false))

func search(query: String) -> Array:
    var terms := normalize(query).split(" ",false)
    matches = []
    marker_counts.clear()
    for row in seed.get("properties",[]):
        var aliases := ""
        for city in seed.get("cities",[]):
            if row[2]==city.name: aliases = city.aliases
        var hay := normalize(" ".join([str(row[1]),str(row[2]),str(row[3]),str(row[8]),aliases]))
        var ok := true
        for term in terms:
            if term in ["in","the","a","spaces","space","properties","property","find","near"]: continue
            if term not in hay: ok = false; break
        if ok:
            matches.append(row)
            marker_counts[row[2]] = marker_counts.get(row[2],0)+1
    result_note = str(matches.size())+" snapshot matches" if not query.strip_edges().is_empty() else "17 local records · Portland & DC"
    refresh_markers()
    return matches

# Original world-surface texture wraps at Greenwich. SphereMesh u increases east.
func geo_point(lat: float, lon: float, radius: float=21.5) -> Vector3:
    var a := deg_to_rad(lon)
    var b := deg_to_rad(lat)
    return Vector3(sin(a)*cos(b),sin(b),cos(a)*cos(b))*radius

func clear_markers() -> void:
    for node in markers.values():
        if is_instance_valid(node): node.hide(); node.queue_free()
    markers.clear()

func refresh_markers() -> void:
    clear_markers()
    if mode!="space": return
    for city in seed.get("cities",[]):
        if not marker_counts.has(city.name): continue
        var node := Node3D.new()
        node.name = "CityMarker_"+str(city.name).replace(" ","_")
        world.earth.add_child(node)
        node.position = geo_point(city.lat,city.lon)
        var dot := MeshInstance3D.new()
        var mesh := SphereMesh.new()
        mesh.radius = .52; mesh.height = 1.04
        dot.mesh = mesh
        var mat := StandardMaterial3D.new()
        mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        mat.albedo_color = Color("FFFFFF")
        dot.material_override = mat
        node.add_child(dot)
        var halo := MeshInstance3D.new()
        var ring := SphereMesh.new()
        ring.radius = .82; ring.height=1.64
        halo.mesh = ring
        var glow := StandardMaterial3D.new()
        glow.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        glow.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        glow.albedo_color = Color(0.1,1,.6,.4)
        halo.material_override=glow
        node.add_child(halo)
        markers[city.name]=node

func focus_city(city_name: String) -> void:
    for city in seed.get("cities",[]):
        if city.name != city_name: continue
        selected_city=city_name
        start_inspection()
        var normal := geo_point(city.lat,city.lon,1.0)
        var towards := (world.camera.global_position-world.earth.global_position).normalized() as Vector3
        # Rotate the original Earth toward the viewer using the selected surface point.
        var rotation := Quaternion(normal,towards)
        target_rotation = Basis(rotation).get_euler()
        focusing=true
        return

func start_inspection() -> void:
    if mode == "world": return
    close_panel()
    if not inspection:
        previous_fov=world.camera.fov
        previous_camera=world.camera.transform
        previous_heading=world.player.rotation.y
        inspection_touch=world.touch_controls.visible
        inspection_mouse=Input.mouse_mode
        world.touch_controls.set_enabled(false)
        Input.mouse_mode=Input.MOUSE_MODE_VISIBLE
        inspection=true
        # Elevated inspection camera clears the existing glass rail without moving the player.
        world.camera.position.y=32.0
        world.camera.fov=clampf(78.0 if get_viewport().get_visible_rect().size.aspect()>=1.0 else 90.0,30.0,90.0)
    var center: Vector3 = world.earth.global_position
    var p: Vector3 = world.player.global_position
    if Vector2(p.x-center.x,p.z-center.z).length()>0.1:
        world.player.look_at(Vector3(center.x,p.y,center.z),Vector3.UP)
        world.camera.look_at(center,Vector3.UP)
    world.player.velocity=Vector3.ZERO
    zoom_row.show()
    selected_label.show()
    selected_label.text=(selected_city+" · pilot location, no live offers" if mode=="cash" else selected_city) if not selected_city.is_empty() else ("EARTH · Cash discovery preview" if mode=="cash" else "EARTH · Geographic discovery")
    if modes.has(mode): selected_label.text = (selected_city+" · geographic reference only" if not selected_city.is_empty() else "EARTH · "+mode_title()+" discovery")
    layout()

func stop_inspection() -> void:
    if inspection:
        world.camera.fov=previous_fov
        world.player.rotation.y=previous_heading
        world.camera.transform=previous_camera
        world.touch_controls.set_enabled(inspection_touch)
        Input.mouse_mode=inspection_mouse
    inspection=false
    focusing=false
    pointer.clear()
    mouse_drag=false
    if is_instance_valid(zoom_row): zoom_row.hide()
    if is_instance_valid(selected_label): selected_label.hide()
    if is_instance_valid(world) and is_instance_valid(world.earth): world.earth.rotation.x=0; world.earth.rotation.z=0

func zoom(factor: float) -> void:
    if inspection: world.camera.fov=clampf(world.camera.fov*factor,30.0,90.0)

func globe_hit(point: Vector2) -> bool:
    var origin: Vector3=world.camera.project_ray_origin(point)
    var direction: Vector3=world.camera.project_ray_normal(point)
    var to_center: Vector3=world.earth.global_position-origin
    var along := to_center.dot(direction)
    return along>0 and (to_center-direction*along).length_squared()<=21.0*21.0

func consume_pointer(event: InputEvent) -> bool:
    if mode == "world" or is_open(): return false
    if event is InputEventScreenDrag and pointer.has(event.index):
        if event.position.distance_to(pointer[event.index].start)>8: pointer[event.index].drag=true
        if pointer[event.index].drag:
            focusing=false
            world.earth.rotation.y += event.relative.x*.012
            world.earth.rotation.x=clampf(world.earth.rotation.x+event.relative.y*.008,-1.5,1.5)
        return true
    if event is InputEventScreenTouch:
        if event.pressed and not event.canceled and globe_hit(event.position):
            pointer[event.index]={"start":event.position,"drag":false}
            return true
        if not event.pressed and pointer.has(event.index):
            var record: Dictionary=pointer[event.index]
            pointer.erase(event.index)
            if not event.canceled and not record.drag: select_marker_or_globe(event.position)
            return true
    if event is InputEventMouseMotion and mouse_drag:
        if event.position.distance_to(mouse_start)>8: mouse_moved=true
        if mouse_moved:
            focusing=false
            world.earth.rotation.y+=event.relative.x*.012
            world.earth.rotation.x=clampf(world.earth.rotation.x+event.relative.y*.008,-1.5,1.5)
        return true
    if event is InputEventMouseButton and not event.pressed and event.button_index==MOUSE_BUTTON_LEFT and mouse_drag:
        mouse_drag=false
        if not mouse_moved: select_marker_or_globe(event.position)
        return true
    if event is InputEventMouseButton and event.pressed:
        var point: Vector2=event.position if Input.mouse_mode!=Input.MOUSE_MODE_CAPTURED else get_viewport().get_visible_rect().get_center()
        if globe_hit(point):
            if event.button_index==MOUSE_BUTTON_LEFT:
                if inspection:
                    mouse_drag=true
                    mouse_start=point
                    mouse_moved=false
                else: select_marker_or_globe(point)
                return true
            if event.button_index==MOUSE_BUTTON_WHEEL_UP: start_inspection(); zoom(.87); return true
            if event.button_index==MOUSE_BUTTON_WHEEL_DOWN: start_inspection(); zoom(1.15); return true
    return false

func select_marker_or_globe(point: Vector2) -> void:
    for city in markers:
        var at: Vector3=markers[city].global_position
        if world.camera.is_position_behind(at): continue
        if (at-world.earth.global_position).dot(world.camera.global_position-at)<=0: continue
        if world.camera.unproject_position(at).distance_to(point)<32:
            show_search(city)
            return
    start_inspection()

func is_open() -> bool: return is_instance_valid(panel) and panel.visible

func close_panel() -> void:
    if not is_open(): return
    panel.hide()
    if inspection:
        zoom_row.show()
        selected_label.show()
    world.touch_controls.set_enabled(saved_touch)
    Input.mouse_mode=saved_mouse

func begin_panel(title: String) -> void:
    if not is_open():
        saved_touch=world.touch_controls.visible
        saved_mouse=Input.mouse_mode
        world.touch_controls.set_enabled(false)
        world.player.velocity=Vector3.ZERO
        Input.mouse_mode=Input.MOUSE_MODE_VISIBLE
    for child in list.get_children(): list.remove_child(child); child.queue_free()
    line(title,22)
    button("Resume exploration",close_panel)
    panel.show()
    for child in list.get_children():
        if child is Button:
            child.grab_focus()
            break
    zoom_row.hide()
    selected_label.hide()
    layout()

func line(value: String, font_size: int=15) -> void:
    var label := Label.new()
    label.text=value
    label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
    label.add_theme_font_size_override("font_size",font_size)
    list.add_child(label)

func button(label: String, callback: Callable) -> Button:
    var b := Button.new()
    b.text=label
    b.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
    b.custom_minimum_size.y=42
    b.pressed.connect(callback)
    list.add_child(b)
    return b

func link(label: String,url: String) -> void:
    button(label,func(): close_panel(); OS.shell_open(url))

func show_search(query: String="") -> void:
    if mode=="cash":
        show_cash_search(query)
        return
    if modes.has(mode):
        show_generic_search(query)
        return
    search(query)
    begin_panel("1AGE SPACE / SEARCH")
    input=LineEdit.new()
    input.placeholder_text="City, address or property"
    input.text=query
    input.text_submitted.connect(show_search)
    list.add_child(input)
    button("Search local index",func(): show_search(input.text))
    line(result_note+" · snapshot 2026-11-25; not a live vacancy feed.")
    for city in marker_counts:
        button("Focus "+city+" on Earth · "+str(marker_counts[city]),focus_city.bind(city))
    for row in matches:
        line(str(row[1])+"\n"+str(row[3])+" · "+str(row[2])+"\nOccupancy: "+str(row[6])+" · "+str(row[7]).replace("_"," "))
        link("Property record",CATALOG+"?property="+str(row[0]).uri_encode())
    if matches.is_empty(): line("No matches in this local snapshot. Try the full Space catalog.")
    link("Search full Space catalog",CATALOG+"?q="+query.uri_encode())

func open_role(index: int) -> void:
    if mode=="cash":
        open_cash_role(index)
        return
    if modes.has(mode):
        open_generic_role(index)
        return
    if index<0 or index>=ROLES.size(): return
    var name_text: String=ROLES[index]
    if name_text=="Properties": show_search(selected_city); return
    begin_panel("1AGE SPACE / "+name_text.to_upper())
    match name_text:
        "HQ1":
            link("Explore Soul District", "https://1age.space/hq1/")
            link("NorthLeftChef", "https://northleftchef.com/?from=hq1&venue=hq1-northleftchef")
            link("No Name Besuto", "https://nonamebesuto.com/?from=hq1&venue=hq1-nnb-gym")
            button("Portland property records",show_search.bind("Portland"))
            button("Focus Portland",focus_city.bind("Portland"))
        "HQ2":
            link("Explore Historic Anacostia", "https://1age.space/hq2/")
            button("Washington property records",show_search.bind("Washington, D.C."))
            button("Focus Washington, D.C.",focus_city.bind("Washington, D.C."))
            line("Protected district · Treasury and metro expansion in development.")
        "Cities", "Districts":
            for city in seed.get("cities",[]):
                link("Visit "+str(city.name),city.url)
                button("Focus "+str(city.name),focus_city.bind(city.name))
            link("Discover more cities",CATALOG)
        "Businesses":
            button("Commercial properties",show_search.bind("commercial"))
            link("Browse catalog",CATALOG+"?category=commercial")
        "Build":
            line("City contribution workflows are planned. No rewards or uploads are enabled here.")
            link("1AGE Quest", "https://1age.quest/")
            link("1AGE Design", "https://1age.design/")
        "Claims":
            line("Real ownership is not transferred here. HQ2 protected properties cannot be claimed. HQ1 studio approval required. Existing catalog claim workflow is a local demonstration only.")
            link("Review property eligibility",CATALOG)
        "Creator Spaces":
            link("Explore creator spaces",CATALOG+"?category=art")
            line("Connect a space via the existing catalog demonstration; publishing is not live here.")
        "Transit":
            link("Portland streets", "https://1age.space/hq1/")
            link("Washington streets", "https://1age.space/hq2/")
            line("Transport routes and boarding will be connected as city builds progress.")
    button("Return to World mode",func(): activate("world"))

func _process(delta: float) -> void:
    if mode=="world": return
    clock+=delta
    if is_instance_valid(world.world_orbit_title): world.world_orbit_title.visible=not inspection
    if focusing:
        world.earth.rotation.x=lerp_angle(world.earth.rotation.x,target_rotation.x,minf(1,delta*4))
        world.earth.rotation.y=lerp_angle(world.earth.rotation.y,target_rotation.y,minf(1,delta*4))
        world.earth.rotation.z=lerp_angle(world.earth.rotation.z,target_rotation.z,minf(1,delta*4))
    for node in markers.values(): node.get_child(1).scale=Vector3.ONE*(1.0+.18*sin(clock*3))
    var messages := ["1AGE SPACE · Virtual Spaces. Real Places.","HQ1 Portland · HQ2 Historic Anacostia",result_note,"Explore the globe · Search properties"]
    if mode=="cash":
        messages=["1AGE CASH · Earn. Use. Explore.","Explore planned earning and use categories",result_note,"Internal credits · No live payments or rewards"]
    if modes.has(mode):
        messages=[mode_title().to_upper()+" · "+str(modes[mode].tagline),"Explore application platforms",result_note,"No connected live feed in this preview"]
    if not selected_city.is_empty(): messages[1]=mode_title().to_upper()+" · "+selected_city+(" · pilot location" if mode=="cash" else "")
    var idx := int(clock/4)%messages.size()
    ticker.text=messages[idx]
    ticker.visible=not is_open() and not world.world_menu.is_open() and not world.terminal_active()

func consume_controller(pressed: Array[bool], prior: Array[bool]) -> bool:
    if is_open():
        if pressed[JOY_BUTTON_B] and not prior[JOY_BUTTON_B]:
            close_panel()
            return true
        var buttons: Array[Button]=[]
        for child in list.get_children():
            if child is Button: buttons.append(child)
        if buttons.is_empty(): return true
        var index:=maxi(0,buttons.find(get_viewport().gui_get_focus_owner()))
        if pressed[JOY_BUTTON_DPAD_DOWN] and not prior[JOY_BUTTON_DPAD_DOWN]: buttons[posmod(index+1,buttons.size())].grab_focus()
        elif pressed[JOY_BUTTON_DPAD_UP] and not prior[JOY_BUTTON_DPAD_UP]: buttons[posmod(index-1,buttons.size())].grab_focus()
        elif pressed[JOY_BUTTON_A] and not prior[JOY_BUTTON_A]: buttons[index].pressed.emit()
        return true
    if inspection:
        if pressed[JOY_BUTTON_B] and not prior[JOY_BUTTON_B]: stop_inspection()
        elif pressed[JOY_BUTTON_RIGHT_SHOULDER] and not prior[JOY_BUTTON_RIGHT_SHOULDER]: zoom(.87)
        elif pressed[JOY_BUTTON_LEFT_SHOULDER] and not prior[JOY_BUTTON_LEFT_SHOULDER]: zoom(1.15)
        elif pressed[JOY_BUTTON_DPAD_LEFT] and not prior[JOY_BUTTON_DPAD_LEFT]: focusing=false; world.earth.rotation.y-=.15
        elif pressed[JOY_BUTTON_DPAD_RIGHT] and not prior[JOY_BUTTON_DPAD_RIGHT]: focusing=false; world.earth.rotation.y+=.15
        return true
    return false


# Data-driven adaptive departments. Private and live-service results fail closed.
func mode_roles() -> Array:
    if not modes.has(mode): return []
    return modes[mode].personal if mode=="page" and personal_page else modes[mode].roles

func generic_search(query: String) -> Array:
    matches=[]
    marker_counts.clear()
    clear_markers()
    var words:=normalize(query).split(" ",false)
    for row in mode_roles():
        var hay:=normalize(str(row.name)+" "+str(row.description))
        var ok:=true
        for word in words:
            if word in ["a","the","in","for","find","1age"]: continue
            if word not in hay: ok=false; break
        if ok: matches.append(row)
    result_note=str(matches.size())+" department matches · no live feed connected"
    return matches

func show_generic_search(query: String="") -> void:
    generic_search(query)
    begin_panel(mode_title().to_upper()+" / DISCOVER")
    input=LineEdit.new()
    input.placeholder_text=str(modes[mode].placeholder)
    input.text=query
    input.text_submitted.connect(show_generic_search)
    list.add_child(input)
    button("Search departments",func(): show_generic_search(input.text))
    line(result_note,13)
    line("Category discovery only. No live profiles, jobs, offers, or private account records are loaded.",13)
    for row in matches: button(str(row.name),open_generic_role.bind(mode_roles().find(row)))
    if matches.is_empty(): line("No matching departments. Geographic data is not connected for this mode.")
    line("Explore geographic references (not live result markers)",14)
    for city in seed.get("cities",[]): button("Focus "+str(city.name),focus_city.bind(city.name))
    if mode=="page": button("Public discovery" if personal_page else "My Page preview",toggle_personal_page)
    button("Return to World mode",func(): activate("world"))

func toggle_personal_page() -> void:
    if mode!="page": return
    var wanted:=not personal_page
    close_panel()
    stop_inspection()
    personal_page=wanted
    # Reuse sign and icon updates, preserving the personal mode selection.
    for i in range(world.APPS.size()):
        var app:String=world.APPS[i]
        var sign:MeshInstance3D=world.find_child("3D_"+app.to_upper(),true,false)
        var icon:Sprite3D=world.find_child("HomepageIcon_"+app,true,false)
        if sign==null or icon==null: continue
        var mesh:=sign.mesh as TextMesh
        mesh.text=role(i).to_upper()
        mesh.pixel_size=.047
        if mesh.get_aabb().size.x>5.8: mesh.pixel_size*=5.8/mesh.get_aabb().size.x
        icon.texture=load("res://world_build0082/homepage_icons/"+str(mode_roles()[i].icon)+".png")
        icon.pixel_size=6.2/float(icon.texture.get_height())
    if is_instance_valid(world.world_orbit_title): world.world_orbit_title.mesh.text=mode_title()
    generic_search("")
    if wanted:
        begin_panel("MY PAGE / PREVIEW")
        line("Sign-in and private portfolio data are not connected. These are account categories, not your actual records.")
        button("Explore my portfolio layout",close_panel)
        button("Return to public discovery",toggle_personal_page)

func open_generic_role(index: int) -> void:
    if index<0 or index>=mode_roles().size(): return
    var row:Dictionary=mode_roles()[index]
    begin_panel(mode_title().to_upper()+" / "+str(row.name).to_upper())
    line(str(row.description))
    if personal_page: line("Account preview only · sign-in required for personal records.",13)
    var action:String=row.action
    if not action.is_empty(): button("Open "+str(row.name),run_generic_action.bind(action))
    else: line("Service integration pending · no live records available.",13)
    button("Search departments",show_generic_search.bind(""))
    if mode=="page": button("Public discovery" if personal_page else "My Page preview",toggle_personal_page)
    button("Return to World mode",func(): activate("world"))

func run_generic_action(action: String) -> void:
    close_panel()
    stop_inspection()
    if action.begins_with("mode:"): activate(action.trim_prefix("mode:"))
    elif action.begins_with("terminal:"): world.platform_terminals.open(action.trim_prefix("terminal:"))
    elif action=="native:games": world._enter_native_platform("res://games_complex/games_complex.tscn")
    elif action=="design":
        world._place_at_platform(world.APPS.find("Design"))
        world.design_platform.toggle_design()
    elif action=="personal": toggle_personal_page()
    elif action.begins_with("https://"): OS.shell_open(action)
