extends SceneTree
var checks := 0
func _initialize(): call_deferred("run")
func verify(ok: bool, msg: String):
    if not ok:
        push_error(msg)
        quit(1)
        assert(ok,msg)
    checks += 1
func capture(path: String):
    if DisplayServer.get_name()=="headless": return
    await process_frame
    await RenderingServer.frame_post_draw
    await process_frame
    await RenderingServer.frame_post_draw
    verify(root.get_texture().get_image().save_png(path)==OK,"capture")
func run():
    root.mode=Window.MODE_WINDOWED
    root.size=Vector2i(1280,720)
    change_scene_to_file("res://world_build0082/world_build0082.tscn")
    await scene_changed
    await physics_frame
    var w=current_scene
    var ship=w.ship_vehicle
    var menu=w.world_menu
    verify(ship.aboard() and ship.cockpit.visible,"initial cockpit")
    verify(ship.lamps.visible,"initial lights")
    verify(w.app_centers.size()==10,"preserved ring")
    verify(menu.logo.global_position.y>menu.search_icon.global_position.y,"vertical crown")
    verify(menu.crown.global_position.distance_to(w.earth.global_position)<32,"world anchor")
    verify(menu.beacons.size()==2,"dual lights")
    var original: Vector3=menu.beacons[0].rotation
    menu._process(1.0)
    verify(original!=menu.beacons[0].rotation,"sway")
    await capture("/mnt/data/1AGE-World-Cockpit-Build010.png")
    menu._activate_target(1)
    menu._process(.4)
    verify(menu.expanded and menu.menu_icons.all(func(n):return n.visible),"four icons")
    verify(menu._hit_target(w.camera.unproject_position(menu.logo.global_position))==1,"projected logo hit")
    await capture("/mnt/data/1AGE-World-Crown-Build010.png")
    menu._activate_target(1)
    verify(not menu.expanded,"close crown")
    ship.toggle_lights()
    verify(not ship.lamps.visible,"lights off")
    ship.toggle_lights()
    verify(ship.lamps.visible,"lights on")
    verify(not ship.request_landing(),"reject remote landing")
    for c in w.app_centers:
        w.reset_ship_arrival()
        w.player.position=c+Vector3.UP*9
        verify(ship.request_landing(),"request valid deck")
        for i in range(300):
            ship.tick(1.0/60.0,true)
            if ship.landed: break
        verify(ship.landed and ship.aboard(),"landed in cockpit")
        ship.board_or_land()
        verify(not ship.aboard() and ship.hull.visible and ship.can_board(),"exit and parked")
        if checks<20: await capture("/mnt/data/1AGE-World-Parked-Build010.png")
        ship.board_or_land()
        verify(ship.aboard() and ship.cockpit.visible and not ship.hull.visible,"board")
    w.reset_ship_arrival()
    for dims in [Vector2i(390,844),Vector2i(844,390),Vector2i(1280,720)]:
        root.size=dims
        await process_frame
        w.touch_controls.layout_controls()
        var pad=w.touch_controls
        verify(pad.buttons.has("lights") and pad.buttons.has("boost") and pad.buttons.has("ship"),"ship actions")
        for key in ["lights","boost","ship"]:
            var at: Vector2=pad.buttons[key].center
            verify(at.x>pad.left_center.x+pad.radius and at.x<pad.right_center.x-pad.radius,"between joysticks")
            verify(at.y>root.size.y-100,"bottom actions")
        if dims.x==390: await capture("/mnt/data/1AGE-World-Portrait-Build010.png")
    print("SHIP AND CROWN CHECKS PASSED: ", checks)
    quit()
