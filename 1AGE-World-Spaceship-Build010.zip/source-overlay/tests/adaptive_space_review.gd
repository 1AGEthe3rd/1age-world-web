extends SceneTree
var checks:=0
func _initialize(): call_deferred("run")
func verify(ok:bool,message:String):
    if not ok:
        push_error(message)
        quit(1)
        assert(ok,message)
    checks+=1
func capture(path:String):
    if DisplayServer.get_name()=="headless": return
    await process_frame
    await RenderingServer.frame_post_draw
    await process_frame
    await RenderingServer.frame_post_draw
    verify(root.get_texture().get_image().save_png(path)==OK,"capture")
func run():
    root.mode=Window.MODE_WINDOWED
    root.size=Vector2i(1280,720)
    change_scene_to_file("res://world_build0082/world_build0082.tscn")
    await scene_changed
    await physics_frame
    await physics_frame
    var world=current_scene
    var a=world.adaptive
    verify(a.mode=="world","default World")
    verify(not a.ticker.visible,"World ticker unchanged")
    verify(world.app_centers.size()==10,"ten decks")
    verify(world.touch_controls.visible,"touch controls")
    verify(world.get_node_or_null("OuterPlatformIntegration")==null,"single ring")
    verify(world.world_menu.crown.get_node_or_null("UniversalRoundMenuLogo")!=null,"beacon")
    verify(a.seed.properties.size()==17,"17 original property records")
    world._destination(1)
    await process_frame
    verify(a.mode=="space","Space activates in place")
    verify(world.app_centers.size()==10,"geometry preserved")
    verify(a.ticker.visible,"Space ticker")
    verify(a.matches.size()==17,"snapshot results")
    verify(a.markers.size()==2,"two city clusters")
    for i in range(10):
        var app:String=world.APPS[i]
        var sign:MeshInstance3D=world.find_child("3D_"+app.to_upper(),true,false)
        var icon:Sprite3D=world.find_child("HomepageIcon_"+app,true,false)
        verify(sign.mesh.text==a.ROLES[i].to_upper(),"repurpose sign "+app)
        verify(icon.texture.resource_path.ends_with(a.ICONS[i]+".png"),"repurpose icon "+app)
        verify(icon.global_position.y-icon.pixel_size*icon.texture.get_height()/2>sign.global_position.y+sign.mesh.get_aabb().end.y+.4,"icon clearance")
        verify(sign.global_position.y+sign.mesh.get_aabb().position.y>45+3.8+.2+1.525+.8,"hologram clearance")
        a.open_role(i)
        verify(a.is_open(),"platform action "+a.ROLES[i])
        verify(not world.touch_controls.visible,"no movement behind panel")
        a.close_panel()
        verify(world.touch_controls.visible,"controls restored")
    verify(a.search("Portland").size()==6,"Portland match")
    verify(a.marker_counts.get("Portland")==6 and a.markers.size()==1,"Portland marker")
    verify(a.search("commercial spaces in DC").size()==9,"DC commercial")
    verify(a.search("MLK Gateway").size()==2,"address search")
    verify(a.search("retail spaces in LA").is_empty() and a.markers.is_empty(),"no fabricated results")
    verify(a.search("Portland").all(func(row): return row[4]==null and row[5]==null),"no invented property coordinates")
    a.focus_city("Portland")
    verify(a.inspection,"inspection active")
    verify(world.globe_inspection_active(),"inspection input gate")
    var fov:float=world.camera.fov
    verify(not world.touch_controls.visible,"inspection controls replace gamepad")
    verify(is_equal_approx(world.camera.position.y,32.0),"elevated globe view")
    a.zoom(.87)
    verify(world.camera.fov<fov,"zoom in")
    a.zoom(1.15)
    verify(world.camera.fov>fov*.87,"zoom out")
    for i in range(90): await physics_frame
    verify(a.globe_hit(root.get_visible_rect().get_center()),"globe hit")
    var marker:Vector3=a.markers.Portland.global_position
    verify((marker-world.earth.global_position).normalized().dot((world.camera.global_position-world.earth.global_position).normalized())>.97,"focus faces viewer")
    await capture("/mnt/data/1AGE-Space-Globe-Build005.png")
    var tap:=InputEventScreenTouch.new()
    tap.index=7; tap.pressed=true; tap.position=root.get_visible_rect().get_center()
    verify(a.consume_pointer(tap),"touch globe capture")
    var drag:=InputEventScreenDrag.new()
    drag.index=7; drag.position=tap.position+Vector2(40,0); drag.relative=Vector2(40,0)
    verify(a.consume_pointer(drag) and not a.focusing,"touch globe rotates")
    tap.pressed=false; tap.position=drag.position
    verify(a.consume_pointer(tap) and a.pointer.is_empty(),"touch released")
    a.stop_inspection()
    verify(is_equal_approx(world.camera.fov,78.0) and world.touch_controls.visible,"zoom and controls restore")
    world.world_menu.open()
    world.world_menu._submit_search("Portland")
    verify(a.is_open() and a.matches.size()==6,"search button routes into Space")
    await capture("/mnt/data/1AGE-Space-Search-Build005.png")
    a.close_panel()
    a.open_role(0)
    await capture("/mnt/data/1AGE-Space-HQ1-Build005.png")
    a.close_panel()
    root.size=Vector2i(390,844)
    await process_frame
    a.search("Washington, D.C.")
    a.focus_city("Washington, D.C.")
    for i in range(70): await physics_frame
    await capture("/mnt/data/1AGE-Space-Portrait-Build005.png")
    a.activate("world")
    verify(not a.ticker.visible and a.markers.is_empty(),"restore World")
    for i in range(10):
        var app:String=world.APPS[i]
        verify(world.find_child("3D_"+app.to_upper(),true,false).mesh.text==app.to_upper(),"restore sign")
        verify(world.find_child("HomepageIcon_"+app,true,false).texture.resource_path.ends_with(app.to_lower()+".png"),"restore icon")
    world._destination(6)
    verify(world.adaptive.mode=="shop","Shop enters adaptive mode")
    world.adaptive.run_generic_action("terminal:Shop")
    verify(world.platform_terminals.opened=="Shop","original seller draft terminal intact")
    world.platform_terminals.close()
    print("ADAPTIVE SPACE CHECKS PASSED: ",checks)
    quit()
