extends SceneTree
var checks:=0
func _initialize(): call_deferred("run")
func verify(ok:bool,msg:String):
    if not ok:
        push_error(msg)
        quit(1)
        assert(ok,msg)
    checks+=1
func capture(path:String):
    if DisplayServer.get_name()=="headless": return
    await process_frame
    await RenderingServer.frame_post_draw
    await process_frame
    await RenderingServer.frame_post_draw
    verify(root.get_texture().get_image().save_png(path)==OK,"capture")
func run():
    root.mode=Window.MODE_WINDOWED
    root.size=Vector2i(1280,720)
    change_scene_to_file("res://world_build0082/world_build0082.tscn")
    await scene_changed
    await physics_frame
    await physics_frame
    var w=current_scene
    var a=w.adaptive
    verify(a.mode=="world","World default")
    w._activate_requested_entry("cash")
    verify(a.mode=="cash","direct Cash domain entry")
    a.activate("world")
    w._destination(8)
    await process_frame
    verify(a.mode=="cash","Cash activates from original deck")
    verify(a.ticker.visible,"ticker active")
    verify(w.app_centers.size()==10,"original geometry")
    verify(a.matches.size()==10,"ten planned categories")
    verify(a.markers.is_empty(),"no funded markers")
    verify(a.result_note.contains("0 published offers"),"clear status")
    verify(a.mode_title()=="1AGE Cash","branding")
    for i in range(10):
        var app:String=w.APPS[i]
        verify(w.find_child("3D_"+app.to_upper(),true,false).mesh.text==app.to_upper(),"matching app name")
        verify(w.find_child("HomepageIcon_"+app,true,false).texture.resource_path.ends_with(app.to_lower()+".png"),"matching app icon")
        w._destination(i)
        verify(a.is_open(),"role opens "+app)
        verify(not w.touch_controls.visible,"movement paused")
        var texts:Array=[]
        for child in a.list.get_children():
            if child is Label or child is Button: texts.append(child.text)
        verify(texts.has("EARN") and texts.has("USE"),"both roles shown")
        verify(texts.has(a.CASH.DISCLAIMER),"preview labeled")
        if i==8: verify(texts.has("Open existing Cash account portal"),"account portal entry")
        a.close_panel()
        verify(w.touch_controls.visible,"movement restored")
    verify(a.cash_search("Portland").size()==4,"pilot categories")
    verify(a.cash_search("jobs in Portland").size()==1,"local work category")
    verify(a.cash_search("Tokyo").is_empty(),"no invented locations")
    verify(a.markers.is_empty(),"no invented offers")
    w.world_menu.open()
    w.world_menu._submit_search("Portland")
    verify(a.is_open() and a.matches.size()==4,"scoped search routes")
    await capture("/mnt/data/1AGE-Cash-Search-Build007.png")
    a.close_panel()
    a.focus_city("Portland")
    verify(a.inspection,"globe inspection")
    verify(a.selected_label.text.contains("no live offers"),"pilot label")
    var fov:float=w.camera.fov
    a.zoom(.87)
    verify(w.camera.fov<fov,"zoom")
    a.stop_inspection()
    verify(w.touch_controls.visible,"controls restored")
    w._place_at_platform(8)
    await physics_frame
    await capture("/mnt/data/1AGE-Cash-World-Build007.png")
    a.open_role(3)
    await capture("/mnt/data/1AGE-Cash-Quest-Build007.png")
    a.close_panel()
    root.size=Vector2i(390,844)
    await process_frame
    a.show_cash_search("Portland")
    await capture("/mnt/data/1AGE-Cash-Portrait-Build007.png")
    a.activate("world")
    verify(a.mode=="world" and not a.ticker.visible,"return World")
    w._destination(1)
    verify(a.mode=="space" and a.matches.size()==17 and a.markers.size()==2,"Space intact")
    a.activate("world")
    print("ADAPTIVE CASH CHECKS PASSED: ",checks)
    quit()
