extends SceneTree
var checks:=0
func _initialize(): call_deferred("run")
func verify(ok:bool,msg:String):
    if not ok:
        push_error(msg)
        quit(1)
        assert(ok,msg)
    checks+=1
func capture(path:String):
    if DisplayServer.get_name()=="headless": return
    await process_frame
    await RenderingServer.frame_post_draw
    await process_frame
    await RenderingServer.frame_post_draw
    verify(root.get_texture().get_image().save_png(path)==OK,"capture")
func run():
    root.mode=Window.MODE_WINDOWED
    root.size=Vector2i(1280,720)
    change_scene_to_file("res://world_build0082/world_build0082.tscn")
    await scene_changed
    await physics_frame
    var w=current_scene
    var a=w.adaptive
    verify(a.mode=="world","World default")
    verify(w.player.position.distance_to(w.SHIP_ARRIVAL)<.1,"Ship arrival position")
    verify(w.movement.mode_name()=="SHIP","Ship arrival mode")
    verify(not w.world_menu.buttons.any(func(b):return b.text=="App"),"No App menu")
    for direct in w.APPS:
        w._activate_requested_entry(direct.to_lower())
        verify(a.mode==direct.to_lower(),"Domain route "+direct)
    a.activate("world")
    await capture("/mnt/data/1AGE-Ship-Arrival-Build009.png")
    w.reset_ship_arrival()
    w._activate_requested_entry("space")
    await capture("/mnt/data/1AGE-Space-Arrival-Build009.png")
    a.activate("world")
    var modes=["page","games","quest","work","forum","shop","exchange","design"]
    for mode in modes:
        a.activate("world")
        w._activate_requested_entry(mode)
        verify(a.mode==mode,"direct entry "+mode)
        verify(a.mode_roles().size()==10,"roles "+mode)
        verify(a.matches.size()==10,"search categories "+mode)
        verify(a.markers.is_empty(),"no fabricated markers")
        verify(w.app_centers.size()==10,"geometry unchanged")
        for i in range(10):
            var row:Dictionary=a.mode_roles()[i]
            var app:String=w.APPS[i]
            verify(w.find_child("3D_"+app.to_upper(),true,false).mesh.text==row.name.to_upper(),"role label")
            verify(w.find_child("HomepageIcon_"+app,true,false).texture.resource_path.ends_with(row.icon+".png"),"icon")
            w._destination(i)
            verify(a.is_open() and not w.touch_controls.visible,"role opens")
            var titles:Array=[]
            for child in a.list.get_children():
                if child is Label: titles.append(child.text)
            verify(titles.has(row.description),"role content")
            a.close_panel()
            verify(w.touch_controls.visible,"restore touch")
        verify(a.generic_search("impossible_xyz").is_empty(),"empty search")
        a.show_search("")
        verify(a.is_open() and a.matches.size()==10,"scope search")
        a.close_panel()
        a.focus_city("Portland")
        verify(a.inspection and a.selected_label.text.contains("reference only"),"geographic preview")
        a.stop_inspection()
        verify(w.touch_controls.visible,"restore controls")
        if mode in ["page","games","work","exchange"]:
            w._place_at_platform(0)
            await physics_frame
            await capture("/mnt/data/1AGE-"+str(mode).capitalize()+"-Build009.png")
        a.activate("world")
        w._destination(w.APPS.find(str(mode).capitalize()))
        verify(a.mode==mode,"ring activates "+mode)
    a.activate("page")
    a.toggle_personal_page()
    verify(a.personal_page and a.role(1)=="Spaces" and a.role(8)=="Cash","personal layout")
    verify(a.is_open(),"personal preview disclosure")
    a.close_panel()
    root.size=Vector2i(390,844)
    await process_frame
    a.open_role(1)
    await capture("/mnt/data/1AGE-MyPage-Build009.png")
    a.close_panel()
    a.toggle_personal_page()
    verify(not a.personal_page and a.role(0)=="People","public restore")
    a.run_generic_action("terminal:Page")
    verify(w.platform_terminals.opened=="Page","native Page terminal")
    w.platform_terminals.close()
    a.activate("quest")
    a.run_generic_action("terminal:Quest")
    verify(w.platform_terminals.opened=="Quest","native Quest terminal")
    w.platform_terminals.close()
    a.activate("shop")
    a.run_generic_action("terminal:Shop")
    verify(w.platform_terminals.opened=="Shop","native Shop terminal")
    w.platform_terminals.close()
    a.run_generic_action("mode:cash")
    verify(a.mode=="cash","cross mode action")
    a.activate("world")
    verify(not a.activate("app"),"App not main mode")
    w._activate_requested_entry("app")
    verify(w.platform_terminals.opened.is_empty(),"App directory disabled")
    w.platform_terminals.open("App")
    verify(w.platform_terminals.opened.is_empty(),"App terminal disabled")
    verify(w.platform_terminals.catalog.entries(false).size()==13,"complete directory")
    w.platform_terminals._travel_to_app("Work")
    verify(a.mode=="work" and w.platform_terminals.opened.is_empty(),"directory opens adaptive mode")
    a.activate("design")
    a.run_generic_action("design")
    verify(w.design_platform.expanded,"native Design tools open")
    w.design_platform.close_design()
    a.activate("games")
    a.run_generic_action("native:games")
    await scene_changed
    verify(current_scene.scene_file_path=="res://games_complex/games_complex.tscn","native games scene opens")
    change_scene_to_file("res://world_build0082/world_build0082.tscn")
    await scene_changed
    verify(current_scene.adaptive.mode=="games","return restores mode")
    print("ALL ADAPTIVE CHECKS PASSED: ",checks)
    quit()
